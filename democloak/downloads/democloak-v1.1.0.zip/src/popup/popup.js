import { parseTabOrigin } from '../shared/selector-utils.js';

const SETTINGS_KEY = 'democloak_settings';

function t(key, fallback = '') {
  try {
    const val = chrome?.i18n?.getMessage?.(key);
    return val || fallback;
  } catch {
    return fallback;
  }
}

function applyI18n() {
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const msg = t(el.dataset.i18n);
    if (msg) el.textContent = msg;
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
    const msg = t(el.dataset.i18nPlaceholder);
    if (msg) el.placeholder = msg;
  });
}

let activeTab = null;
let originInfo = null;
let appStatus = null;
let currentMaskStyle = 'blur';
let activeTabState = null;

const elHost = document.getElementById('site-host');
const elPlanPill = document.getElementById('plan-pill');
const elBanner = document.getElementById('status-banner');
const elStats = document.getElementById('active-stats');
const elQuotaTag = document.getElementById('quota-tag');
const elCustomTerms = document.getElementById('custom-terms');
const elCustomLimitHint = document.getElementById('custom-limit-hint');
const elSavedRuleBar = document.getElementById('saved-rule-bar');
const elSavedRuleText = document.getElementById('saved-rule-text');
const elProDrawer = document.getElementById('pro-drawer');
const elProPrice = document.getElementById('pro-price');
const elBuyPro = document.getElementById('btn-buy-pro');
const elLicenseInput = document.getElementById('license-input');
const elProActiveBox = document.getElementById('pro-active-box');

const btnAuto = document.getElementById('btn-auto');
const btnPicker = document.getElementById('btn-picker');
const btnDraw = document.getElementById('btn-draw');
const btnPanic = document.getElementById('btn-panic');
const btnRestore = document.getElementById('btn-restore');
const btnSaveSite = document.getElementById('btn-save-site');
const btnRemoveSite = document.getElementById('btn-remove-site');
const btnScreenshot = document.getElementById('btn-screenshot');
const btnClosePro = document.getElementById('btn-close-pro');
const btnActivate = document.getElementById('btn-activate');
const btnDeactivate = document.getElementById('btn-deactivate');

function showBanner(text, isError = false) {
  elBanner.textContent = text;
  elBanner.classList.toggle('error', isError);
  elBanner.classList.remove('hidden');
}

function clearBanner() {
  elBanner.classList.add('hidden');
}

function getSelectedCategories() {
  const categories = { custom: true };
  document.querySelectorAll('#category-chips input[type="checkbox"]').forEach((box) => {
    categories[box.dataset.cat] = box.checked;
  });
  return categories;
}

function getCustomTermsList() {
  return String(elCustomTerms.value || '')
    .split(/[\n,]+/)
    .map((s) => s.trim())
    .filter((s) => s.length >= 2);
}

async function persistSettings() {
  await chrome.storage.local.set({
    [SETTINGS_KEY]: {
      maskStyle: currentMaskStyle,
      categories: getSelectedCategories(),
      customTermsRaw: elCustomTerms.value,
    },
  });
}

async function ensureContentReady() {
  if (!activeTab?.id) throw new Error('No active webpage found.');
  if (!originInfo) throw new Error('DemoCloak runs on standard http/https webpages.');
  try {
    const res = await chrome.tabs.sendMessage(activeTab.id, { type: 'DC_PING' });
    if (res?.ok) return res;
  } catch {
    // Inject engine now
  }
  await chrome.scripting.executeScript({
    target: { tabId: activeTab.id },
    files: ['src/content/cloak-engine.js'],
  });
  return chrome.tabs.sendMessage(activeTab.id, { type: 'DC_PING' });
}

async function sendTabAction(payload) {
  await ensureContentReady();
  const res = await chrome.tabs.sendMessage(activeTab.id, payload);
  activeTabState = res;
  renderTabState();
  return res;
}

function renderTabState() {
  const total = (activeTabState?.autoCount || 0)
    + (activeTabState?.manualCount || 0)
    + (activeTabState?.boxCount || 0);
  elStats.textContent = `${total} ${t('maskedSuffix', 'masked')}`;
  btnPicker.classList.toggle('active-mode', Boolean(activeTabState?.pickerActive));
  btnDraw.classList.toggle('active-mode', Boolean(activeTabState?.drawActive));
  btnPanic.classList.toggle('active-mode', Boolean(activeTabState?.panicActive));
}

function renderAppStatus() {
  if (!appStatus) return;
  const isPro = Boolean(appStatus.license?.isPro);
  elPlanPill.textContent = isPro ? t('proBadge', 'PRO') : t('freeUpgrade', 'FREE · UPGRADE');
  elPlanPill.className = `plan-pill ${isPro ? 'pro' : 'free'}`;

  if (isPro) {
    elQuotaTag.textContent = t('unlimited', 'Unlimited');
    elCustomLimitHint.textContent = t('customUnlimitedHint', '(unlimited)');
    elProActiveBox.classList.remove('hidden');
  } else {
    const rem = appStatus.quota?.remaining ?? 0;
    const lim = appStatus.quota?.limit ?? 3;
    elQuotaTag.textContent = `${rem}/${lim} ${t('todayLeft', 'left today')}`;
    elCustomLimitHint.textContent = t('customFreeHint', `(up to ${appStatus.config.freeMaxCustomTerms} free)`);
    elProActiveBox.classList.add('hidden');
  }

  elBuyPro.href = appStatus.config.checkoutUrl;
  elBuyPro.textContent = t('buyProBtn', `Get Lifetime License (${appStatus.config.launchPrice})`);

  const rule = originInfo && appStatus.domainRules?.[originInfo.hostname];
  if (rule?.enabled) {
    elSavedRuleBar.classList.remove('hidden');
    elSavedRuleText.textContent = `${t('autoApplySite', 'Auto-apply ON')}: ${originInfo.hostname}`;
  } else {
    elSavedRuleBar.classList.add('hidden');
  }
}

async function refreshStatus() {
  appStatus = await chrome.runtime.sendMessage({ type: 'DC_GET_STATUS' });
  if (appStatus?.settings) {
    currentMaskStyle = appStatus.settings.maskStyle || 'blur';
    document.querySelectorAll('.seg-btn').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.style === currentMaskStyle);
    });
    if (appStatus.settings.categories) {
      document.querySelectorAll('#category-chips input[type="checkbox"]').forEach((box) => {
        if (typeof appStatus.settings.categories[box.dataset.cat] === 'boolean') {
          box.checked = appStatus.settings.categories[box.dataset.cat];
        }
      });
    }
    if (typeof appStatus.settings.customTermsRaw === 'string') {
      elCustomTerms.value = appStatus.settings.customTermsRaw;
    }
  }
  renderAppStatus();
}

async function init() {
  applyI18n();
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  activeTab = tab || null;
  originInfo = parseTabOrigin(tab?.url);
  elHost.textContent = originInfo ? originInfo.hostname : t('internalPage', 'Browser internal page');

  await refreshStatus();

  if (activeTab?.id && originInfo) {
    try {
      activeTabState = await chrome.tabs.sendMessage(activeTab.id, { type: 'DC_PING' });
      renderTabState();
    } catch {
      // Engine not yet injected on this tab
    }
  }
}

// Mask Style segmented control
document.querySelectorAll('.seg-btn').forEach((btn) => {
  btn.addEventListener('click', async () => {
    currentMaskStyle = btn.dataset.style;
    document.querySelectorAll('.seg-btn').forEach((b) => b.classList.toggle('active', b === btn));
    await persistSettings();
  });
});

document.querySelectorAll('#category-chips input[type="checkbox"]').forEach((box) => {
  box.addEventListener('change', () => { persistSettings().catch(() => {}); });
});
elCustomTerms.addEventListener('change', () => { persistSettings().catch(() => {}); });

// Auto-Shield Page (3/day Free, Unlimited Pro)
btnAuto.addEventListener('click', async () => {
  clearBanner();
  try {
    await persistSettings();
    const quotaRes = await chrome.runtime.sendMessage({ type: 'DC_CONSUME_SCAN_QUOTA' });
    if (!quotaRes?.allowed) {
      elProDrawer.classList.remove('hidden');
      showBanner(t('msgLimitReached', 'Daily free Auto-Shield limit reached (3/day). Manual Click-to-Blur & Box Blur stay unlimited, or unlock Pro once.'), true);
      return;
    }

    const isPro = Boolean(quotaRes.isPro);
    const maxCustomTerms = isPro ? Infinity : (appStatus?.config?.freeMaxCustomTerms ?? 2);
    const res = await sendTabAction({
      type: 'DC_RUN_AUTO_SHIELD',
      config: {
        maskStyle: currentMaskStyle,
        categories: getSelectedCategories(),
        customTerms: getCustomTermsList(),
        maxCustomTerms,
      },
    });
    await refreshStatus();
    await chrome.runtime.sendMessage({
      type: 'DC_UPDATE_BADGE',
      tabId: activeTab.id,
      text: res.matchedCount > 0 ? String(Math.min(99, res.matchedCount)) : 'ON',
      color: '#10b981',
    });

    const modeLabel = currentMaskStyle === 'demo' ? 'Demo Data swapped' : currentMaskStyle === 'redact' ? 'redacted' : 'blurred';
    showBanner(`Protected ${res.matchedCount} sensitive item${res.matchedCount === 1 ? '' : 's'} (${modeLabel}). Live updates stay masked.`);
  } catch (err) {
    showBanner(err.message || 'Could not scan this page.', true);
  }
});

btnPicker.addEventListener('click', async () => {
  clearBanner();
  try {
    await sendTabAction({
      type: 'DC_TOGGLE_PICKER',
      style: currentMaskStyle === 'redact' ? 'redact' : 'blur',
    });
    window.close();
  } catch (err) {
    showBanner(err.message || 'Could not start element picker.', true);
  }
});

btnDraw.addEventListener('click', async () => {
  clearBanner();
  try {
    await sendTabAction({
      type: 'DC_TOGGLE_DRAW',
      style: currentMaskStyle === 'redact' ? 'redact' : 'blur',
    });
    window.close();
  } catch (err) {
    showBanner(err.message || 'Could not start box draw mode.', true);
  }
});

btnPanic.addEventListener('click', async () => {
  clearBanner();
  try {
    const res = await sendTabAction({ type: 'DC_TOGGLE_PANIC_VEIL' });
    await chrome.runtime.sendMessage({
      type: 'DC_UPDATE_BADGE',
      tabId: activeTab.id,
      text: res.panicActive ? 'VEIL' : '',
      color: '#6366f1',
    });
    window.close();
  } catch (err) {
    showBanner(err.message || 'Could not toggle privacy veil.', true);
  }
});

btnRestore.addEventListener('click', async () => {
  clearBanner();
  try {
    await sendTabAction({ type: 'DC_RESTORE_ALL' });
    await chrome.runtime.sendMessage({
      type: 'DC_UPDATE_BADGE',
      tabId: activeTab.id,
      text: '',
    });
    showBanner(t('msgRestored', 'Restored original page cleanly.'));
  } catch (err) {
    showBanner(err.message || 'Nothing to restore on this tab.', true);
  }
});

// Save Per-Domain Rule: call chrome.permissions.request synchronously before any await!
btnSaveSite.addEventListener('click', async () => {
  clearBanner();
  if (!originInfo) {
    showBanner('Open a regular website to save auto-apply rules.', true);
    return;
  }

  const granted = await chrome.permissions.request({ origins: [originInfo.originPattern] });
  if (!granted) {
    showBanner('Site permission is required only for automatic masking when this site loads.', true);
    return;
  }

  try {
    await persistSettings();
    let selectors = [];
    try {
      const ping = await chrome.tabs.sendMessage(activeTab.id, { type: 'DC_PING' });
      selectors = ping?.manualSelectors || [];
    } catch {
      // No manual selectors yet — auto-shield rule still saves cleanly
    }
    const res = await chrome.runtime.sendMessage({
      type: 'DC_SAVE_DOMAIN_RULE',
      hostname: originInfo.hostname,
      rule: {
        maskStyle: currentMaskStyle,
        autoShield: true,
        categories: getSelectedCategories(),
        customTerms: getCustomTermsList(),
        selectors,
      },
    });
    if (!res?.ok) {
      if (res?.limitReached) elProDrawer.classList.remove('hidden');
      showBanner(res?.error || 'Could not save site rule.', true);
      return;
    }
    await refreshStatus();
    showBanner(`Auto-apply saved for ${originInfo.hostname}. Sensitive fields will mask on load.`);
  } catch (err) {
    showBanner(err.message || 'Failed to save rule.', true);
  }
});

btnRemoveSite.addEventListener('click', async () => {
  if (!originInfo) return;
  await chrome.runtime.sendMessage({
    type: 'DC_DELETE_DOMAIN_RULE',
    hostname: originInfo.hostname,
  });
  await refreshStatus();
  showBanner(`Removed auto-apply rule for ${originInfo.hostname}.`);
});

// Clean Local Screenshot (PNG)
btnScreenshot.addEventListener('click', async () => {
  clearBanner();
  try {
    if (activeTab?.id && originInfo) {
      try {
        await chrome.tabs.sendMessage(activeTab.id, { type: 'DC_PREPARE_SCREENSHOT' });
      } catch {
        // OK if engine wasn't injected
      }
    }
    const dataUrl = await chrome.tabs.captureVisibleTab(activeTab.windowId, { format: 'png' });
    const hostSlug = (originInfo?.hostname || 'page').replace(/[^a-z0-9.-]/gi, '_');
    const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `democloak-${hostSlug}-${ts}.png`;
    link.click();
    showBanner(t('msgPngSaved', 'Saved clean masked PNG screenshot locally.'));
  } catch (err) {
    showBanner(err.message || 'Could not capture screenshot on this tab.', true);
  }
});

// Pro Drawer & License Controls
elPlanPill.addEventListener('click', () => {
  elProDrawer.classList.toggle('hidden');
});

btnClosePro.addEventListener('click', () => {
  elProDrawer.classList.add('hidden');
});

btnActivate.addEventListener('click', async () => {
  clearBanner();
  const key = elLicenseInput.value.trim();
  if (!key) {
    showBanner('Paste your DemoCloak Pro license key first.', true);
    return;
  }
  btnActivate.disabled = true;
  btnActivate.textContent = t('checkingBtn', 'Checking…');
  try {
    const res = await chrome.runtime.sendMessage({
      type: 'DC_ACTIVATE_LICENSE',
      licenseKey: key,
    });
    if (!res?.ok) {
      showBanner(res?.error || 'License activation failed.', true);
      return;
    }
    elLicenseInput.value = '';
    await refreshStatus();
    showBanner(t('msgProActivated', 'DemoCloak Pro activated! Unlimited scans, Demo Mode & saved sites unlocked.'));
  } finally {
    btnActivate.disabled = false;
    btnActivate.textContent = t('activateBtn', 'Activate');
  }
});

btnDeactivate.addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'DC_DEACTIVATE_LICENSE' });
  await refreshStatus();
  showBanner(t('msgDeactivated', 'License deactivated from this browser.'));
});

init().catch((err) => {
  showBanner(err.message || 'Failed to initialize DemoCloak.', true);
});
