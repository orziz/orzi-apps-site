/**
 * DemoCloak commercial & monetization configuration (Orzi Apps Studio · Creem.io + Cloudflare Worker).
 */
export const CONFIG = Object.freeze({
  APP_NAME: 'DemoCloak',
  VERSION: '1.1.0',

  // Creem Product ID for DemoCloak Pro — Lifetime License (wired to shared multi-product Worker)
  PRODUCT_ID: 'prod_6K9gLu8EsdUHKgYfFd8Suc',

  // Shared multi-product Cloudflare Worker proxying Creem.io /v1/licenses/*
  LICENSE_API_BASE: 'https://orzi-apps-license-api.orzi-apps.workers.dev',

  // Public Creem.io Checkout URL ($19 one-time lifetime Pro license)
  CHECKOUT_URL: 'https://www.creem.io/payment/prod_6K9gLu8EsdUHKgYfFd8Suc',
  HOMEPAGE_URL: 'https://apps.orzi.me/democloak/',
  STUDIO_URL: 'https://apps.orzi.me/',
  PRIVACY_URL: 'https://apps.orzi.me/privacy.html',
  TERMS_URL: 'https://apps.orzi.me/terms.html',
  SUPPORT_URL: 'https://github.com/orziz/orzi-apps-site/issues',

  // Pricing display strings
  LAUNCH_PRICE: '$19',
  STANDARD_PRICE: '$39',

  // Free tier limits (generous manual click/box blur unlimited; daily quota on Auto-PII & Demo Mode)
  FREE_DAILY_AUTO_SCANS: 3,
  FREE_MAX_SAVED_DOMAINS: 1,
  FREE_MAX_CUSTOM_TERMS: 2,

  // License revalidation & offline grace window
  REVALIDATE_INTERVAL_MS: 12 * 60 * 60 * 1000, // 12 hours
  OFFLINE_GRACE_MS: 7 * 24 * 60 * 60 * 1000,   // 7 days
});
