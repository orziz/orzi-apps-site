/**
 * DemoCloak In-Page Cloak Engine (Classic content script injected on-demand via chrome.scripting).
 * Supports:
 * 1. Click-to-Blur / Redact Element Picker (Shadow DOM HUD, zero style collision)
 * 2. Drag Region Blur / Redact Box Overlay (scroll-anchored)
 * 3. 1-Click Auto-PII & Secret Shield with Blur, Solid Redact, and Deterministic Realistic Demo Mode
 * 4. Live SPA MutationObserver auto-masking (batched via requestAnimationFrame)
 * 5. Instant Panic Privacy Veil (Alt+Shift+B)
 * 6. Lossless 1-Click Restore All
 */
(() => {
  if (window.__DEMOCLOAK_ENGINE_LOADED__) return;
  window.__DEMOCLOAK_ENGINE_LOADED__ = true;

  const STYLE_ID = 'democloak-page-styles';
  const HOST_ID = 'democloak-shadow-host';

  const FAKE_EMAILS = [
    'alex.chen@acme.example',
    'maya.patel@northstar.example',
    'jordan.lee@lumen.example',
    'sam.rivera@kestrel.example',
    'elena.rostova@verve.example',
    'marcus.cole@cobalt.example',
    'priya.nair@aurora.example',
    'liam.brooks@summit.example',
    'nina.foster@harbor.example',
    'devon.park@meridian.example',
    'chloe.bennett@solstice.example',
    'tariq.hassan@cedar.example',
  ];

  const FAKE_PHONES = [
    '+1 (415) 555-0142',
    '+1 (212) 555-0189',
    '+1 (312) 555-0174',
    '+1 (650) 555-0126',
    '+1 (206) 555-0193',
    '+1 (512) 555-0168',
  ];

  const FAKE_IPS = [
    '192.0.2.44',
    '192.0.2.108',
    '198.51.100.18',
    '198.51.100.73',
    '203.0.113.29',
    '203.0.113.91',
  ];

  const FAKE_CUSTOM_LABELS = [
    'Acme Corp',
    'Northstar Labs',
    'Lumen Systems',
    'Kestrel Studio',
    'Cobalt Cloud',
    'Summit Works',
  ];

  function hashString(input) {
    const str = String(input || '');
    let h = 0x811c9dc5;
    for (let i = 0; i < str.length; i += 1) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 0x01000193);
    }
    return h >>> 0;
  }

  function isValidLuhn(digitsOnly) {
    const digits = String(digitsOnly || '').replace(/\D/g, '');
    if (digits.length < 13 || digits.length > 19) return false;
    if (/^(\d)\1+$/.test(digits)) return false;
    let sum = 0;
    let dbl = false;
    for (let i = digits.length - 1; i >= 0; i -= 1) {
      let d = digits.charCodeAt(i) - 48;
      if (dbl) {
        d *= 2;
        if (d > 9) d -= 9;
      }
      sum += d;
      dbl = !dbl;
    }
    return sum % 10 === 0;
  }

  function fakeMoneyValue(original) {
    const str = String(original || '').trim();
    const h = hashString(str);
    const match = str.match(/^([+-]?\s*)(US\$|CA\$|AU\$|HK\$|NT\$|USD|EUR|GBP|CNY|JPY|[$€£¥])(\s*)([\d,.\s]+?)(\s*[kKmMbB]|\s*(?:USD|EUR|GBP|CNY|JPY))?$/);
    if (!match) {
      return `$${(1200 + (h % 24000)).toLocaleString('en-US')}.00`;
    }
    const [, signPart, currency, spaceAfter, numRaw, suffix = ''] = match;
    const trimmedNum = numRaw.trim();
    const hasComma = trimmedNum.includes(',');
    const dotIdx = trimmedNum.lastIndexOf('.');
    const commaIdx = trimmedNum.lastIndexOf(',');
    const euroDecimal = commaIdx > dotIdx && trimmedNum.length - commaIdx - 1 === 2;
    let decimals = 0;
    let numericVal = 0;
    if (euroDecimal) {
      decimals = 2;
      numericVal = parseFloat(trimmedNum.replace(/\./g, '').replace(',', '.'));
    } else {
      if (dotIdx !== -1) decimals = Math.min(2, trimmedNum.length - dotIdx - 1);
      numericVal = parseFloat(trimmedNum.replace(/[,\s]/g, ''));
    }
    if (!Number.isFinite(numericVal)) return `${signPart}${currency}${spaceAfter}1,420.00${suffix}`;
    const factor = 0.68 + ((h % 115) / 100);
    let fakeVal = Math.max(decimals > 0 ? 1.5 : 5, numericVal * factor);
    if (fakeVal >= 1000) fakeVal = Math.round(fakeVal / 10) * 10;
    else if (fakeVal >= 100) fakeVal = Math.round(fakeVal);
    else if (decimals === 0) fakeVal = Math.max(1, Math.round(fakeVal));
    else fakeVal = Math.round(fakeVal * 100) / 100;

    let formatted;
    if (euroDecimal) {
      const [intPart, decPart] = fakeVal.toFixed(decimals).split('.');
      formatted = `${intPart.replace(/\B(?=(\d{3})+(?!\d))/g, '.')},${decPart}`;
    } else {
      const [intPart, decPart] = fakeVal.toFixed(decimals).split('.');
      const grouped = hasComma || fakeVal >= 1000
        ? intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
        : intPart;
      formatted = decPart !== undefined ? `${grouped}.${decPart}` : grouped;
    }
    return `${signPart}${currency}${spaceAfter}${formatted}${suffix}`;
  }

  function fakeSecretValue(original) {
    const str = String(original || '');
    const h = hashString(str).toString(16).padStart(4, '0').slice(0, 4);
    if (/^Bearer\s+/i.test(str)) return `Bearer demo_token_••••${h}`;
    if (/^eyJ/.test(str)) return `eyJhbGci.demo_••••${h}`;
    const prefixMatch = str.match(/^(sk_(?:live|test)_|pk_(?:live|test)_|sk-|gh[pousr]_|github_pat_|AKIA|AIza|xox[baprs]-|creem_)/);
    if (prefixMatch) return `${prefixMatch[1]}demo_••••${h}`;
    return `demo_secret_••••${h}`;
  }

  function generateFakeReplacement(category, originalText) {
    const h = hashString(originalText);
    switch (category) {
      case 'emails': return FAKE_EMAILS[h % FAKE_EMAILS.length];
      case 'secrets': return fakeSecretValue(originalText);
      case 'money': return fakeMoneyValue(originalText);
      case 'cards': return `•••• •••• •••• ${String(4000 + (h % 5000)).slice(-4)}`;
      case 'phones': return FAKE_PHONES[h % FAKE_PHONES.length];
      case 'ips': return FAKE_IPS[h % FAKE_IPS.length];
      case 'custom': return FAKE_CUSTOM_LABELS[h % FAKE_CUSTOM_LABELS.length];
      default: return '••••••••';
    }
  }

  function escapeRegex(literal) {
    return literal.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function parseCustomRules(rawList, maxTerms = Infinity) {
    const items = Array.isArray(rawList)
      ? rawList
      : String(rawList || '').split(/[\n,]+/);
    const compiled = [];
    for (const raw of items) {
      if (compiled.length >= maxTerms) break;
      const term = String(raw || '').trim();
      if (!term || term.length < 2 || term.length > 120) continue;
      if (term.startsWith('/') && term.endsWith('/') && term.length > 2) {
        try {
          compiled.push(new RegExp(term.slice(1, -1), 'gi'));
        } catch {
          // ignore bad regex
        }
      } else {
        compiled.push(new RegExp(escapeRegex(term), 'gi'));
      }
    }
    return compiled;
  }

  const DETECTORS = [
    {
      category: 'secrets',
      regex: /\b(?:sk_(?:live|test)_[A-Za-z0-9]{12,}|pk_(?:live|test)_[A-Za-z0-9]{12,}|sk-[A-Za-z0-9_-]{18,}|creem_[A-Za-z0-9_-]{12,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[0-9A-Z]{16}|AIza[0-9A-Za-z_-]{35}|xox[baprs]-[0-9A-Za-z-]{10,}|eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{8,}|Bearer\s+[A-Za-z0-9._-]{20,})\b/g,
    },
    {
      category: 'emails',
      regex: /\b[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9.-]{1,190}\.[A-Za-z]{2,14}\b/g,
    },
    {
      category: 'cards',
      regex: /\b(?:\d[ -]*?){13,19}\b/g,
      validate: (text) => {
        const digits = text.replace(/\D/g, '');
        if (digits.length < 13 || digits.length > 19) return false;
        if (/^20\d{2}-\d{2}-\d{2}/.test(text)) return false;
        return isValidLuhn(digits);
      },
    },
    {
      category: 'money',
      regex: /(?:[+-]\s*)?(?:(?:US\$|CA\$|AU\$|HK\$|NT\$|[$€£¥])\s*\d{1,3}(?:[,\s.]\d{3})*(?:[.,]\d{1,2})?(?:\s*[kKmMbB])?|\b(?:USD|EUR|GBP|CNY|JPY)\s+\d{1,3}(?:[,\s.]\d{3})*(?:[.,]\d{1,2})?(?:\s*[kKmMbB])?)/g,
      validate: (text) => /\d/.test(text),
    },
    {
      category: 'phones',
      regex: /(?<!\d)(?:\+\d{1,3}[\s.-]?)?(?:\(\d{2,4}\)[\s.-]?|\d{3}[\s.-])\d{3,4}[\s.-]\d{4}(?!\d)/g,
      validate: (text) => {
        const digits = text.replace(/\D/g, '');
        if (digits.length < 10 || digits.length > 15) return false;
        if (/^20\d{2}[.-]\d{2}[.-]\d{2}/.test(text)) return false;
        return true;
      },
    },
    {
      category: 'ips',
      regex: /(?<![\dvV.])(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}(?![\d.])/g,
    },
  ];

  function findSensitiveMatches(text, options) {
    if (!text || typeof text !== 'string') return [];
    const categories = options.categories || {};
    const customRules = categories.custom
      ? parseCustomRules(options.customTerms || [], options.maxCustomTerms ?? Infinity)
      : [];
    const rawMatches = [];

    for (const detector of DETECTORS) {
      if (!categories[detector.category]) continue;
      detector.regex.lastIndex = 0;
      let m;
      while ((m = detector.regex.exec(text)) !== null) {
        const matched = m[0];
        if (!matched) {
          detector.regex.lastIndex += 1;
          continue;
        }
        if (detector.validate && !detector.validate(matched)) continue;
        rawMatches.push({
          start: m.index,
          end: m.index + matched.length,
          text: matched,
          category: detector.category,
          priority: detector.category === 'secrets' ? 1 : detector.category === 'emails' ? 2 : 3,
        });
      }
    }

    for (const rule of customRules) {
      rule.lastIndex = 0;
      let m;
      while ((m = rule.exec(text)) !== null) {
        const matched = m[0];
        if (!matched) {
          rule.lastIndex += 1;
          continue;
        }
        rawMatches.push({
          start: m.index,
          end: m.index + matched.length,
          text: matched,
          category: 'custom',
          priority: 0,
        });
      }
    }

    if (rawMatches.length === 0) return [];
    rawMatches.sort((a, b) => a.start - b.start || a.priority - b.priority || (b.end - b.start) - (a.end - a.start));

    const accepted = [];
    let cursor = -1;
    for (const item of rawMatches) {
      if (item.start < cursor) continue;
      accepted.push({
        start: item.start,
        end: item.end,
        text: item.text,
        category: item.category,
        replacement: generateFakeReplacement(item.category, item.text),
      });
      cursor = item.end;
    }
    return accepted;
  }

  function isLikelyStableId(val) {
    if (!val || val.length > 48) return false;
    if (/\d{4,}/.test(val)) return false;
    if (/^(?:css|sc|emotion|styled|jsx|radix|headlessui|mui)-/i.test(val)) return false;
    if (/^:r[0-9a-z]+:$/i.test(val)) return false;
    if (/^[a-f0-9]{8,}$/i.test(val)) return false;
    return /^[A-Za-z_-][A-Za-z0-9_-]*$/.test(val);
  }

  function buildStableSelector(el) {
    if (!el || el.nodeType !== 1) return '';
    const testId = el.getAttribute('data-testid') || el.getAttribute('data-test-id');
    if (testId && testId.length <= 64) {
      const sel = `[data-testid="${testId.replace(/"/g, '\\"')}"]`;
      try {
        if (document.querySelectorAll(sel).length === 1) return sel;
      } catch {}
    }
    if (el.id && isLikelyStableId(el.id)) {
      const sel = `#${CSS.escape(el.id)}`;
      try {
        if (document.querySelectorAll(sel).length === 1) return sel;
      } catch {}
    }
    const parts = [];
    let cur = el;
    let depth = 0;
    while (cur && cur.nodeType === 1 && cur.tagName !== 'HTML' && cur.tagName !== 'BODY' && depth < 5) {
      if (cur.id && isLikelyStableId(cur.id)) {
        parts.unshift(`#${CSS.escape(cur.id)}`);
        break;
      }
      let part = cur.tagName.toLowerCase();
      const classes = Array.from(cur.classList)
        .filter((c) => isLikelyStableId(c) && !c.startsWith('dc-'))
        .slice(0, 2);
      if (classes.length) part += classes.map((c) => `.${CSS.escape(c)}`).join('');
      const parent = cur.parentElement;
      if (parent) {
        const same = Array.from(parent.children).filter((s) => s.tagName === cur.tagName);
        if (same.length > 1) part += `:nth-of-type(${same.indexOf(cur) + 1})`;
      }
      parts.unshift(part);
      const candidate = parts.join(' > ');
      try {
        if (document.querySelectorAll(candidate).length === 1) return candidate;
      } catch {}
      cur = parent;
      depth += 1;
    }
    return parts.join(' > ');
  }

  // Runtime state for this tab
  const state = {
    pickerActive: false,
    pickerStyle: 'blur',
    drawActive: false,
    drawStyle: 'blur',
    panicActive: false,
    autoActive: false,
    autoConfig: null,
    autoCount: 0,
    manualSelectors: new Set(),
    maskedElements: new Set(),
    maskedInputs: new Map(),
    boxes: [],
    observer: null,
    mutationTimer: null,
    dragStart: null,
    activePreviewBox: null,
  };

  // Inject minimal page-level masking CSS once
  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
      [data-dc-el-mode="blur"] {
        filter: blur(8px) !important;
        user-select: none !important;
        transition: filter 120ms ease !important;
      }
      [data-dc-el-mode="redact"] {
        position: relative !important;
        color: transparent !important;
        background: #0f172a !important;
        border-radius: 4px !important;
        user-select: none !important;
      }
      [data-dc-el-mode="redact"] * {
        visibility: hidden !important;
      }
      span.dc-auto-mask[data-dc-mode="blur"] {
        filter: blur(6px) !important;
        display: inline-block !important;
        user-select: none !important;
        padding: 0 2px !important;
      }
      span.dc-auto-mask[data-dc-mode="redact"] {
        background: #0f172a !important;
        color: transparent !important;
        border-radius: 3px !important;
        padding: 0 3px !important;
        user-select: none !important;
      }
      span.dc-auto-mask[data-dc-mode="demo"] {
        font: inherit !important;
        color: inherit !important;
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  // Shadow DOM host for isolated HUD, hover outline, drag boxes, and panic veil
  let shadowRoot = null;
  let hudBanner = null;
  let hoverBox = null;
  let boxLayer = null;
  let panicLayer = null;

  function ensureShadowUI() {
    if (shadowRoot && document.getElementById(HOST_ID)) return;
    const host = document.createElement('div');
    host.id = HOST_ID;
    host.style.cssText = 'position:absolute;top:0;left:0;width:0;height:0;z-index:2147483646;pointer-events:none;';
    document.documentElement.appendChild(host);
    shadowRoot = host.attachShadow({ mode: 'open' });

    const css = document.createElement('style');
    css.textContent = `
      .dc-hud {
        position: fixed;
        bottom: 18px;
        left: 50%;
        transform: translateX(-50%);
        background: rgba(15, 23, 42, 0.94);
        color: #f8fafc;
        border: 1px solid rgba(52, 211, 153, 0.55);
        border-radius: 999px;
        padding: 8px 16px;
        font: 600 13px/1.3 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        display: none;
        align-items: center;
        gap: 10px;
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.35);
        pointer-events: auto;
        z-index: 2147483647;
      }
      .dc-hud.visible { display: flex; }
      .dc-hud-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #34d399;
      }
      .dc-hud-btn {
        background: rgba(255, 255, 255, 0.12);
        color: #f8fafc;
        border: 0;
        border-radius: 999px;
        padding: 4px 10px;
        font: 600 12px/1 -apple-system, sans-serif;
        cursor: pointer;
      }
      .dc-hud-btn:hover { background: rgba(255, 255, 255, 0.22); }
      .dc-hover {
        position: fixed;
        border: 2px solid #34d399;
        background: rgba(16, 185, 129, 0.12);
        border-radius: 4px;
        pointer-events: none;
        display: none;
        z-index: 2147483645;
        box-sizing: border-box;
      }
      .dc-box {
        position: absolute;
        border-radius: 6px;
        z-index: 2147483640;
        box-sizing: border-box;
        pointer-events: none;
      }
      .dc-box.mode-blur {
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        background: rgba(15, 23, 42, 0.18);
      }
      .dc-box.mode-redact {
        background: #0f172a;
      }
      .dc-box.editing {
        pointer-events: auto;
        outline: 1.5px dashed rgba(52, 211, 153, 0.85);
      }
      .dc-box-del {
        display: none;
        position: absolute;
        top: -10px;
        right: -10px;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        border: 0;
        background: #ef4444;
        color: #fff;
        font: 700 12px/20px sans-serif;
        cursor: pointer;
        text-align: center;
        padding: 0;
      }
      .dc-box.editing:hover .dc-box-del { display: block; }
      .dc-box-preview {
        position: absolute;
        border: 2px dashed #34d399;
        background: rgba(16, 185, 129, 0.16);
        border-radius: 6px;
        pointer-events: none;
        z-index: 2147483646;
      }
      .dc-panic {
        position: fixed;
        inset: 0;
        backdrop-filter: blur(26px);
        -webkit-backdrop-filter: blur(26px);
        background: rgba(9, 13, 26, 0.72);
        display: none;
        align-items: center;
        justify-content: center;
        pointer-events: auto;
        z-index: 2147483647;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      }
      .dc-panic.visible { display: flex; }
      .dc-panic-card {
        background: rgba(15, 23, 42, 0.95);
        border: 1px solid rgba(148, 163, 184, 0.25);
        border-radius: 16px;
        padding: 24px 32px;
        text-align: center;
        color: #f8fafc;
        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.45);
      }
      .dc-panic-card h2 { margin: 0 0 8px; font-size: 18px; }
      .dc-panic-card p { margin: 0 0 16px; font-size: 13px; color: #94a3b8; }
      .dc-panic-card button {
        background: #10b981;
        color: #052e16;
        border: 0;
        border-radius: 8px;
        padding: 9px 18px;
        font: 700 13px/1 -apple-system, sans-serif;
        cursor: pointer;
      }
    `;
    shadowRoot.appendChild(css);

    boxLayer = document.createElement('div');
    shadowRoot.appendChild(boxLayer);

    hoverBox = document.createElement('div');
    hoverBox.className = 'dc-hover';
    shadowRoot.appendChild(hoverBox);

    hudBanner = document.createElement('div');
    hudBanner.className = 'dc-hud';
    const dot = document.createElement('span');
    dot.className = 'dc-hud-dot';
    const label = document.createElement('span');
    label.className = 'dc-hud-text';
    const doneBtn = document.createElement('button');
    doneBtn.className = 'dc-hud-btn';
    doneBtn.textContent = 'Done (Esc)';
    doneBtn.addEventListener('click', () => {
      stopPicker();
      stopDrawMode();
    });
    hudBanner.append(dot, label, doneBtn);
    shadowRoot.appendChild(hudBanner);

    panicLayer = document.createElement('div');
    panicLayer.className = 'dc-panic';
    const card = document.createElement('div');
    card.className = 'dc-panic-card';
    const h2 = document.createElement('h2');
    h2.textContent = 'Privacy Veil Active';
    const p = document.createElement('p');
    p.textContent = 'Press Alt+Shift+B or click below to reveal this tab.';
    const revealBtn = document.createElement('button');
    revealBtn.textContent = 'Reveal Tab';
    revealBtn.addEventListener('click', () => setPanicVeil(false));
    card.append(h2, p, revealBtn);
    panicLayer.appendChild(card);
    shadowRoot.appendChild(panicLayer);
  }

  function showHud(text) {
    ensureShadowUI();
    const label = hudBanner.querySelector('.dc-hud-text');
    if (label) label.textContent = text;
    hudBanner.classList.add('visible');
  }

  function hideHud() {
    if (hudBanner) hudBanner.classList.remove('visible');
  }

  function refreshBoxEditingState() {
    if (!boxLayer) return;
    const isEditing = state.drawActive || state.pickerActive;
    boxLayer.querySelectorAll('.dc-box').forEach((el) => {
      el.classList.toggle('editing', isEditing);
    });
  }

  function isOwnElement(node) {
    if (!node) return false;
    const host = document.getElementById(HOST_ID);
    return node === host || (host && host.contains(node));
  }

  // ---- Click-to-Blur Picker ----
  function onPickerMouseMove(e) {
    if (!state.pickerActive) return;
    const target = document.elementFromPoint(e.clientX, e.clientY);
    if (!target || isOwnElement(target) || target === document.body || target === document.documentElement) {
      hoverBox.style.display = 'none';
      return;
    }
    const rect = target.getBoundingClientRect();
    hoverBox.style.display = 'block';
    hoverBox.style.top = `${rect.top}px`;
    hoverBox.style.left = `${rect.left}px`;
    hoverBox.style.width = `${rect.width}px`;
    hoverBox.style.height = `${rect.height}px`;
  }

  function onPickerClick(e) {
    if (!state.pickerActive) return;
    if (isOwnElement(e.target)) return;
    e.preventDefault();
    e.stopPropagation();

    const target = document.elementFromPoint(e.clientX, e.clientY);
    if (!target || isOwnElement(target) || target === document.body || target === document.documentElement) return;

    ensureStyles();
    if (target.hasAttribute('data-dc-el-mode')) {
      const sel = target.getAttribute('data-dc-selector');
      target.removeAttribute('data-dc-el-mode');
      target.removeAttribute('data-dc-selector');
      state.maskedElements.delete(target);
      if (sel) state.manualSelectors.delete(sel);
    } else {
      const sel = buildStableSelector(target);
      target.setAttribute('data-dc-el-mode', state.pickerStyle === 'redact' ? 'redact' : 'blur');
      if (sel) {
        target.setAttribute('data-dc-selector', sel);
        state.manualSelectors.add(sel);
      }
      state.maskedElements.add(target);
    }
  }

  function onKeyDown(e) {
    if (e.key === 'Escape') {
      if (state.pickerActive || state.drawActive) {
        stopPicker();
        stopDrawMode();
      } else if (state.panicActive) {
        setPanicVeil(false);
      }
    }
  }

  function startPicker(style = 'blur') {
    stopDrawMode();
    ensureStyles();
    ensureShadowUI();
    state.pickerActive = true;
    state.pickerStyle = style === 'redact' ? 'redact' : 'blur';
    document.addEventListener('mousemove', onPickerMouseMove, true);
    document.addEventListener('click', onPickerClick, true);
    document.addEventListener('keydown', onKeyDown, true);
    document.documentElement.style.cursor = 'crosshair';
    showHud(`Click any element to ${state.pickerStyle} (click again to unmask)`);
    refreshBoxEditingState();
  }

  function stopPicker() {
    if (!state.pickerActive) return;
    state.pickerActive = false;
    document.removeEventListener('mousemove', onPickerMouseMove, true);
    document.removeEventListener('click', onPickerClick, true);
    document.documentElement.style.cursor = '';
    if (hoverBox) hoverBox.style.display = 'none';
    if (!state.drawActive) hideHud();
    refreshBoxEditingState();
  }

  // ---- Drag Box Region Mask ----
  function addBlurBox(rect, mode = 'blur') {
    ensureShadowUI();
    const box = document.createElement('div');
    box.className = `dc-box mode-${mode === 'redact' ? 'redact' : 'blur'}`;
    box.style.left = `${rect.left}px`;
    box.style.top = `${rect.top}px`;
    box.style.width = `${rect.width}px`;
    box.style.height = `${rect.height}px`;

    const del = document.createElement('button');
    del.className = 'dc-box-del';
    del.textContent = '×';
    del.title = 'Remove blur box';
    del.addEventListener('click', (ev) => {
      ev.stopPropagation();
      box.remove();
      state.boxes = state.boxes.filter((b) => b.el !== box);
    });
    box.appendChild(del);
    boxLayer.appendChild(box);
    state.boxes.push({ el: box, rect, mode });
    refreshBoxEditingState();
  }

  function onDrawMouseDown(e) {
    if (!state.drawActive || e.button !== 0 || isOwnElement(e.target)) return;
    e.preventDefault();
    e.stopPropagation();
    const x = e.clientX + window.scrollX;
    const y = e.clientY + window.scrollY;
    state.dragStart = { x, y };
    const preview = document.createElement('div');
    preview.className = 'dc-box-preview';
    preview.style.left = `${x}px`;
    preview.style.top = `${y}px`;
    preview.style.width = '0px';
    preview.style.height = '0px';
    boxLayer.appendChild(preview);
    state.activePreviewBox = preview;
  }

  function onDrawMouseMove(e) {
    if (!state.drawActive || !state.dragStart || !state.activePreviewBox) return;
    const cx = e.clientX + window.scrollX;
    const cy = e.clientY + window.scrollY;
    const left = Math.min(state.dragStart.x, cx);
    const top = Math.min(state.dragStart.y, cy);
    const width = Math.abs(cx - state.dragStart.x);
    const height = Math.abs(cy - state.dragStart.y);
    state.activePreviewBox.style.left = `${left}px`;
    state.activePreviewBox.style.top = `${top}px`;
    state.activePreviewBox.style.width = `${width}px`;
    state.activePreviewBox.style.height = `${height}px`;
  }

  function onDrawMouseUp(e) {
    if (!state.drawActive || !state.dragStart) return;
    e.preventDefault();
    e.stopPropagation();
    const cx = e.clientX + window.scrollX;
    const cy = e.clientY + window.scrollY;
    const left = Math.min(state.dragStart.x, cx);
    const top = Math.min(state.dragStart.y, cy);
    const width = Math.abs(cx - state.dragStart.x);
    const height = Math.abs(cy - state.dragStart.y);

    if (state.activePreviewBox) {
      state.activePreviewBox.remove();
      state.activePreviewBox = null;
    }
    state.dragStart = null;
    if (width >= 10 && height >= 10) {
      addBlurBox({ left, top, width, height }, state.drawStyle);
    }
  }

  function startDrawMode(style = 'blur') {
    stopPicker();
    ensureShadowUI();
    state.drawActive = true;
    state.drawStyle = style === 'redact' ? 'redact' : 'blur';
    document.addEventListener('mousedown', onDrawMouseDown, true);
    document.addEventListener('mousemove', onDrawMouseMove, true);
    document.addEventListener('mouseup', onDrawMouseUp, true);
    document.addEventListener('keydown', onKeyDown, true);
    document.documentElement.style.cursor = 'crosshair';
    showHud(`Drag to draw ${state.drawStyle} boxes (hover box to delete)`);
    refreshBoxEditingState();
  }

  function stopDrawMode() {
    if (!state.drawActive) return;
    state.drawActive = false;
    state.dragStart = null;
    if (state.activePreviewBox) {
      state.activePreviewBox.remove();
      state.activePreviewBox = null;
    }
    document.removeEventListener('mousedown', onDrawMouseDown, true);
    document.removeEventListener('mousemove', onDrawMouseMove, true);
    document.removeEventListener('mouseup', onDrawMouseUp, true);
    document.documentElement.style.cursor = '';
    if (!state.pickerActive) hideHud();
    refreshBoxEditingState();
  }

  // ---- Auto-PII & Realistic Demo Mode Engine ----
  const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'SVG', 'CANVAS', 'IFRAME', 'TEXTAREA']);

  function unwrapAutoMasks() {
    const spans = Array.from(document.querySelectorAll('span.dc-auto-mask'));
    for (const span of spans) {
      const orig = span.getAttribute('data-dc-orig');
      const parent = span.parentNode;
      if (parent && orig !== null) {
        parent.replaceChild(document.createTextNode(orig), span);
        parent.normalize();
      }
    }
    for (const [input, origVal] of state.maskedInputs.entries()) {
      if (input.isConnected) {
        input.value = origVal;
        input.removeAttribute('data-dc-input-masked');
        input.style.removeProperty('filter');
      }
    }
    state.maskedInputs.clear();
    state.autoCount = 0;
  }

  async function scanRootForSensitiveData(rootNode, config) {
    ensureStyles();
    const maskMode = config.maskStyle || 'blur';
    const textNodes = [];
    const walker = document.createTreeWalker(rootNode, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        if (SKIP_TAGS.has(parent.tagName)) return NodeFilter.FILTER_REJECT;
        if (parent.closest(`#${HOST_ID}, .dc-auto-mask, [contenteditable="true"]`)) {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      },
    });

    let current;
    while ((current = walker.nextNode())) {
      textNodes.push(current);
    }

    let matchedCount = 0;
    const BATCH = 35;

    for (let i = 0; i < textNodes.length; i += BATCH) {
      const batch = textNodes.slice(i, i + BATCH);
      await new Promise((resolve) => {
        requestAnimationFrame(() => {
          for (const textNode of batch) {
            if (!textNode.isConnected) continue;
            const raw = textNode.nodeValue;
            const matches = findSensitiveMatches(raw, config);
            if (!matches.length) continue;

            const frag = document.createDocumentFragment();
            let lastIdx = 0;
            for (const m of matches) {
              if (m.start > lastIdx) {
                frag.appendChild(document.createTextNode(raw.slice(lastIdx, m.start)));
              }
              const span = document.createElement('span');
              span.className = 'dc-auto-mask';
              span.setAttribute('data-dc-mode', maskMode);
              span.setAttribute('data-dc-cat', m.category);
              span.setAttribute('data-dc-orig', m.text);
              span.textContent = maskMode === 'demo' ? m.replacement : m.text;
              frag.appendChild(span);
              lastIdx = m.end;
              matchedCount += 1;
            }
            if (lastIdx < raw.length) {
              frag.appendChild(document.createTextNode(raw.slice(lastIdx)));
            }
            textNode.parentNode?.replaceChild(frag, textNode);
          }
          resolve();
        });
      });
    }

    // Also scan non-password visible inputs
    const inputs = rootNode.querySelectorAll
      ? rootNode.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"], input[type="search"], input:not([type])')
      : [];
    for (const input of inputs) {
      if (state.maskedInputs.has(input) || !input.value) continue;
      const matches = findSensitiveMatches(input.value, config);
      if (!matches.length) continue;
      state.maskedInputs.set(input, input.value);
      input.setAttribute('data-dc-input-masked', '1');
      if (maskMode === 'demo') {
        let nextVal = '';
        let cursor = 0;
        for (const m of matches) {
          nextVal += input.value.slice(cursor, m.start) + m.replacement;
          cursor = m.end;
        }
        nextVal += input.value.slice(cursor);
        input.value = nextVal;
      } else {
        input.style.filter = 'blur(6px)';
      }
      matchedCount += matches.length;
    }

    state.autoCount += matchedCount;
    return matchedCount;
  }

  function startObserver() {
    if (state.observer) state.observer.disconnect();
    state.observer = new MutationObserver((mutations) => {
      if (!state.autoActive || !state.autoConfig) return;
      const addedRoots = new Set();
      for (const mut of mutations) {
        for (const node of mut.addedNodes) {
          if (node.nodeType === 1 && !isOwnElement(node) && !node.classList?.contains('dc-auto-mask')) {
            addedRoots.add(node);
          }
        }
      }
      if (!addedRoots.size) return;
      clearTimeout(state.mutationTimer);
      state.mutationTimer = setTimeout(() => {
        for (const root of addedRoots) {
          if (root.isConnected) {
            scanRootForSensitiveData(root, state.autoConfig).catch(() => {});
          }
        }
      }, 220);
    });
    state.observer.observe(document.body || document.documentElement, {
      childList: true,
      subtree: true,
    });
  }

  async function applyAutoShield(config) {
    unwrapAutoMasks();
    state.autoActive = true;
    state.autoConfig = config;
    const count = await scanRootForSensitiveData(document.body || document.documentElement, config);
    startObserver();
    return count;
  }

  function setPanicVeil(active) {
    ensureShadowUI();
    state.panicActive = Boolean(active);
    panicLayer.classList.toggle('visible', state.panicActive);
    if (state.panicActive) {
      document.addEventListener('keydown', onKeyDown, true);
    }
    return state.panicActive;
  }

  function restoreAll() {
    stopPicker();
    stopDrawMode();
    setPanicVeil(false);
    if (state.observer) {
      state.observer.disconnect();
      state.observer = null;
    }
    state.autoActive = false;
    state.autoConfig = null;
    unwrapAutoMasks();

    for (const el of Array.from(state.maskedElements)) {
      el.removeAttribute('data-dc-el-mode');
      el.removeAttribute('data-dc-selector');
    }
    state.maskedElements.clear();
    state.manualSelectors.clear();

    for (const b of state.boxes) b.el.remove();
    state.boxes = [];
  }

  async function applySavedDomainRule(rule) {
    ensureStyles();
    if (Array.isArray(rule.selectors)) {
      const styleMode = rule.maskStyle === 'redact' ? 'redact' : 'blur';
      for (const sel of rule.selectors) {
        try {
          const matches = document.querySelectorAll(sel);
          matches.forEach((el) => {
            el.setAttribute('data-dc-el-mode', styleMode);
            el.setAttribute('data-dc-selector', sel);
            state.maskedElements.add(el);
            state.manualSelectors.add(sel);
          });
        } catch {
          // ignore invalid saved selector
        }
      }
    }
    if (rule.autoShield) {
      await applyAutoShield({
        maskStyle: rule.maskStyle || 'blur',
        categories: rule.categories || {},
        customTerms: rule.customTerms || [],
      });
    }
  }

  function getTabState() {
    return {
      ok: true,
      pickerActive: state.pickerActive,
      drawActive: state.drawActive,
      panicActive: state.panicActive,
      autoActive: state.autoActive,
      autoCount: state.autoCount,
      manualCount: state.maskedElements.size,
      boxCount: state.boxes.length,
      manualSelectors: Array.from(state.manualSelectors),
    };
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    (async () => {
      switch (msg?.type) {
        case 'DC_PING':
          sendResponse(getTabState());
          return;
        case 'DC_TOGGLE_PICKER':
          if (state.pickerActive) stopPicker();
          else startPicker(msg.style || 'blur');
          sendResponse(getTabState());
          return;
        case 'DC_TOGGLE_DRAW':
          if (state.drawActive) stopDrawMode();
          else startDrawMode(msg.style || 'blur');
          sendResponse(getTabState());
          return;
        case 'DC_TOGGLE_PANIC_VEIL':
          setPanicVeil(!state.panicActive);
          sendResponse(getTabState());
          return;
        case 'DC_RUN_AUTO_SHIELD': {
          const count = await applyAutoShield(msg.config || {});
          sendResponse({ ...getTabState(), matchedCount: count });
          return;
        }
        case 'DC_APPLY_DOMAIN_RULE':
          await applySavedDomainRule(msg.rule || {});
          sendResponse(getTabState());
          return;
        case 'DC_RESTORE_ALL':
          restoreAll();
          sendResponse(getTabState());
          return;
        case 'DC_PREPARE_SCREENSHOT':
          stopPicker();
          stopDrawMode();
          hideHud();
          sendResponse({ ok: true });
          return;
        default:
          sendResponse({ ok: false });
      }
    })();
    return true;
  });
})();
