import { CONFIG } from '../shared/config.js';
import { createLicenseClient } from '../shared/license-client.js';
import { parseTabOrigin } from '../shared/selector-utils.js';

const DOMAIN_RULES_KEY = 'democloak_domain_rules';
const SETTINGS_KEY = 'democloak_settings';

const licenseClient = createLicenseClient();

async function getSavedDomainRules() {
  const res = await chrome.storage.local.get([DOMAIN_RULES_KEY]);
  return res[DOMAIN_RULES_KEY] || {};
}

async function saveDomainRules(rulesMap) {
  await chrome.storage.local.set({ [DOMAIN_RULES_KEY]: rulesMap });
}

async function ensureContentEngine(tabId) {
  try {
    const ping = await chrome.tabs.sendMessage(tabId, { type: 'DC_PING' });
    if (ping?.ok) return true;
  } catch {
    // Not injected yet
  }
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ['src/content/cloak-engine.js'],
  });
  return true;
}

async function sendToTab(tabId, payload) {
  await ensureContentEngine(tabId);
  return chrome.tabs.sendMessage(tabId, payload);
}

// Auto-apply saved per-domain rules when user has granted optional host permission for that site
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete' || !tab?.url) return;
  const originInfo = parseTabOrigin(tab.url);
  if (!originInfo) return;

  try {
    const hasPerm = await chrome.permissions.contains({ origins: [originInfo.originPattern] });
    if (!hasPerm) return;

    const rulesMap = await getSavedDomainRules();
    const rule = rulesMap[originInfo.hostname];
    if (!rule || !rule.enabled) return;

    await sendToTab(tabId, {
      type: 'DC_APPLY_DOMAIN_RULE',
      rule,
    });
    await chrome.action.setBadgeText({ tabId, text: 'ON' });
    await chrome.action.setBadgeBackgroundColor({ tabId, color: '#10b981' });
  } catch {
    // Restricted page (chrome://, store, etc.) — skip quietly
  }
});

// Keyboard shortcuts (direct user gesture -> activeTab works without broad host permissions)
chrome.commands.onCommand.addListener(async (command) => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;

    if (command === 'panic-veil') {
      const res = await sendToTab(tab.id, { type: 'DC_TOGGLE_PANIC_VEIL' });
      await chrome.action.setBadgeText({ tabId: tab.id, text: res?.panicActive ? 'VEIL' : '' });
      if (res?.panicActive) {
        await chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color: '#6366f1' });
      }
    } else if (command === 'toggle-picker') {
      const { [SETTINGS_KEY]: settings = {} } = await chrome.storage.local.get([SETTINGS_KEY]);
      await sendToTab(tab.id, {
        type: 'DC_TOGGLE_PICKER',
        style: settings.maskStyle === 'redact' ? 'redact' : 'blur',
      });
    }
  } catch {
    // Cannot inject into browser internal pages
  }
});

// Background message router for Popup UI
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    try {
      switch (message?.type) {
        case 'DC_GET_STATUS': {
          const [license, quota, rulesMap, settingsRes] = await Promise.all([
            licenseClient.getLicenseState(),
            licenseClient.getDailyQuotaStatus(),
            getSavedDomainRules(),
            chrome.storage.local.get([SETTINGS_KEY]),
          ]);

          // Background-refresh stale Pro licenses quietly
          if (license.isPro && license.status === 'stale') {
            licenseClient.validateLicense().catch(() => {});
          }

          sendResponse({
            ok: true,
            config: {
              version: CONFIG.VERSION,
              launchPrice: CONFIG.LAUNCH_PRICE,
              standardPrice: CONFIG.STANDARD_PRICE,
              checkoutUrl: CONFIG.CHECKOUT_URL,
              homepageUrl: CONFIG.HOMEPAGE_URL,
              freeMaxSavedDomains: CONFIG.FREE_MAX_SAVED_DOMAINS,
              freeMaxCustomTerms: CONFIG.FREE_MAX_CUSTOM_TERMS,
            },
            license,
            quota,
            domainRules: rulesMap,
            settings: settingsRes[SETTINGS_KEY] || null,
          });
          return;
        }

        case 'DC_ACTIVATE_LICENSE': {
          const res = await licenseClient.activateLicense(message.licenseKey);
          sendResponse(res);
          return;
        }

        case 'DC_DEACTIVATE_LICENSE': {
          const res = await licenseClient.deactivateLicense();
          sendResponse(res);
          return;
        }

        case 'DC_CONSUME_SCAN_QUOTA': {
          const res = await licenseClient.consumeAutoScanQuota();
          sendResponse({ ok: true, ...res });
          return;
        }

        case 'DC_SAVE_DOMAIN_RULE': {
          const { hostname, rule } = message;
          if (!hostname) {
            sendResponse({ ok: false, error: 'Missing hostname.' });
            return;
          }
          const [license, rulesMap] = await Promise.all([
            licenseClient.getLicenseState(),
            getSavedDomainRules(),
          ]);
          const existingKeys = Object.keys(rulesMap);
          const alreadyExists = Boolean(rulesMap[hostname]);
          if (!license.isPro && !alreadyExists && existingKeys.length >= CONFIG.FREE_MAX_SAVED_DOMAINS) {
            sendResponse({
              ok: false,
              limitReached: true,
              error: `Free plan includes ${CONFIG.FREE_MAX_SAVED_DOMAINS} auto-apply site. Upgrade to Pro (${CONFIG.LAUNCH_PRICE} one-time) for unlimited sites.`,
            });
            return;
          }
          rulesMap[hostname] = {
            ...rule,
            enabled: true,
            updatedAt: Date.now(),
          };
          await saveDomainRules(rulesMap);
          sendResponse({ ok: true, domainRules: rulesMap });
          return;
        }

        case 'DC_DELETE_DOMAIN_RULE': {
          const { hostname } = message;
          const rulesMap = await getSavedDomainRules();
          delete rulesMap[hostname];
          await saveDomainRules(rulesMap);
          sendResponse({ ok: true, domainRules: rulesMap });
          return;
        }

        case 'DC_UPDATE_BADGE': {
          if (typeof message.tabId === 'number') {
            await chrome.action.setBadgeText({
              tabId: message.tabId,
              text: message.text || '',
            });
            if (message.color) {
              await chrome.action.setBadgeBackgroundColor({
                tabId: message.tabId,
                color: message.color,
              });
            }
          }
          sendResponse({ ok: true });
          return;
        }

        default:
          sendResponse({ ok: false, error: 'Unknown message type.' });
      }
    } catch (err) {
      sendResponse({ ok: false, error: err?.message || 'Unexpected error.' });
    }
  })();
  return true;
});
