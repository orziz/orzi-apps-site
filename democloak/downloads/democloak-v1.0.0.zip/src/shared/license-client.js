import { CONFIG } from './config.js';

const STORAGE_KEYS = Object.freeze({
  LICENSE: 'democloak_license',
  INSTANCE_NAME: 'democloak_instance_name',
  QUOTA: 'democloak_daily_quota',
});

function getDefaultStorage() {
  return {
    async get(keys) {
      return chrome.storage.local.get(keys);
    },
    async set(items) {
      return chrome.storage.local.set(items);
    },
    async remove(keys) {
      return chrome.storage.local.remove(keys);
    },
  };
}

function getTodayKey(nowMs = Date.now()) {
  const d = new Date(nowMs);
  const yyyy = d.getUTCFullYear();
  const mm = String(d.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(d.getUTCDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

async function getOrCreateInstanceName(storage) {
  const stored = await storage.get([STORAGE_KEYS.INSTANCE_NAME]);
  if (stored[STORAGE_KEYS.INSTANCE_NAME]) {
    return stored[STORAGE_KEYS.INSTANCE_NAME];
  }
  const randomPart = typeof crypto !== 'undefined' && crypto.randomUUID
    ? crypto.randomUUID().slice(0, 8)
    : Math.random().toString(36).slice(2, 10);
  const instanceName = `democloak-chrome-${randomPart}`;
  await storage.set({ [STORAGE_KEYS.INSTANCE_NAME]: instanceName });
  return instanceName;
}

/**
 * License & daily quota client for DemoCloak talking to the shared Orzi Apps Creem.io Worker.
 */
export function createLicenseClient({
  fetchImpl = globalThis.fetch,
  storage = getDefaultStorage(),
  config = CONFIG,
  now = () => Date.now(),
} = {}) {
  function getApiBase() {
    return String(config.LICENSE_API_BASE || '').trim().replace(/\/+$/, '');
  }

  async function getLicenseState() {
    const stored = await storage.get([STORAGE_KEYS.LICENSE]);
    const rec = stored[STORAGE_KEYS.LICENSE];
    if (!rec || !rec.licenseKey || !rec.instanceId) {
      return { isPro: false, status: 'free', record: null };
    }
    const elapsed = now() - (rec.lastValidatedAt || 0);
    if (rec.isPro && elapsed <= config.OFFLINE_GRACE_MS) {
      return {
        isPro: true,
        status: elapsed > config.REVALIDATE_INTERVAL_MS ? 'stale' : 'active',
        record: rec,
      };
    }
    return { isPro: false, status: 'expired_cache', record: rec };
  }

  async function activateLicense(rawKey) {
    const licenseKey = String(rawKey || '').trim();
    if (!licenseKey || licenseKey.length < 6) {
      return { ok: false, error: 'Please enter a valid DemoCloak Pro license key.' };
    }

    const apiBase = getApiBase();
    if (!apiBase) {
      return {
        ok: false,
        error: 'License verification endpoint is not configured.',
      };
    }

    const instanceName = await getOrCreateInstanceName(storage);

    try {
      const response = await fetchImpl(`${apiBase}/activate`, {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          key: licenseKey,
          instance_name: instanceName,
          product_id: config.PRODUCT_ID || undefined,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data?.ok || !data?.valid || !data?.instance_id) {
        return { ok: false, error: data?.error || 'License activation failed.' };
      }

      const record = {
        isPro: true,
        licenseKey: data.key || licenseKey,
        instanceId: data.instance_id,
        instanceName,
        expiresAt: data.expires_at || null,
        activatedAt: now(),
        lastValidatedAt: now(),
      };

      await storage.set({ [STORAGE_KEYS.LICENSE]: record });
      return { ok: true, record };
    } catch (err) {
      return { ok: false, error: `Network error while activating license: ${err.message}` };
    }
  }

  async function validateLicense({ force = false } = {}) {
    const stored = await storage.get([STORAGE_KEYS.LICENSE]);
    const rec = stored[STORAGE_KEYS.LICENSE];
    if (!rec?.licenseKey || !rec?.instanceId) {
      return { ok: false, isPro: false, status: 'free' };
    }

    const elapsed = now() - (rec.lastValidatedAt || 0);
    if (!force && elapsed < config.REVALIDATE_INTERVAL_MS && rec.isPro) {
      return { ok: true, isPro: true, status: 'cached', record: rec };
    }

    const apiBase = getApiBase();
    if (!apiBase) {
      return { ok: false, isPro: false, status: 'unconfigured' };
    }

    try {
      const response = await fetchImpl(`${apiBase}/validate`, {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          key: rec.licenseKey,
          instance_id: rec.instanceId,
          product_id: config.PRODUCT_ID || undefined,
        }),
      });

      const data = await response.json();
      if (response.ok && data?.ok && data?.valid) {
        const updated = { ...rec, isPro: true, lastValidatedAt: now() };
        await storage.set({ [STORAGE_KEYS.LICENSE]: updated });
        return { ok: true, isPro: true, status: 'validated', record: updated };
      }

      await storage.remove([STORAGE_KEYS.LICENSE]);
      return {
        ok: false,
        isPro: false,
        status: 'revoked',
        error: data?.error || 'License is no longer active.',
      };
    } catch {
      if (rec.isPro && elapsed <= config.OFFLINE_GRACE_MS) {
        return { ok: true, isPro: true, status: 'offline_grace', record: rec };
      }
      return { ok: false, isPro: false, status: 'offline_expired' };
    }
  }

  async function deactivateLicense() {
    const stored = await storage.get([STORAGE_KEYS.LICENSE]);
    const rec = stored[STORAGE_KEYS.LICENSE];
    const apiBase = getApiBase();
    if (apiBase && rec?.licenseKey && rec?.instanceId) {
      try {
        await fetchImpl(`${apiBase}/deactivate`, {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            key: rec.licenseKey,
            instance_id: rec.instanceId,
          }),
        });
      } catch {
        // Still clear local state even if offline
      }
    }
    await storage.remove([STORAGE_KEYS.LICENSE]);
    return { ok: true };
  }

  async function getDailyQuotaStatus() {
    const license = await getLicenseState();
    if (license.isPro) {
      return {
        isPro: true,
        used: 0,
        limit: Infinity,
        remaining: Infinity,
        canUseProFeature: true,
      };
    }
    const today = getTodayKey(now());
    const stored = await storage.get([STORAGE_KEYS.QUOTA]);
    const quota = stored[STORAGE_KEYS.QUOTA];
    const used = quota && quota.date === today ? Number(quota.used || 0) : 0;
    const remaining = Math.max(0, config.FREE_DAILY_AUTO_SCANS - used);
    return {
      isPro: false,
      used,
      limit: config.FREE_DAILY_AUTO_SCANS,
      remaining,
      canUseProFeature: remaining > 0,
    };
  }

  async function consumeAutoScanQuota() {
    const status = await getDailyQuotaStatus();
    if (status.isPro) {
      return { allowed: true, ...status };
    }
    if (!status.canUseProFeature) {
      return { allowed: false, ...status };
    }
    const today = getTodayKey(now());
    const nextUsed = status.used + 1;
    await storage.set({ [STORAGE_KEYS.QUOTA]: { date: today, used: nextUsed } });
    return {
      allowed: true,
      isPro: false,
      used: nextUsed,
      limit: config.FREE_DAILY_AUTO_SCANS,
      remaining: Math.max(0, config.FREE_DAILY_AUTO_SCANS - nextUsed),
      canUseProFeature: nextUsed < config.FREE_DAILY_AUTO_SCANS,
    };
  }

  return {
    getLicenseState,
    activateLicense,
    validateLicense,
    deactivateLicense,
    getDailyQuotaStatus,
    consumeAutoScanQuota,
  };
}
