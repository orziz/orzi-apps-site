/**
 * Stable CSS selector generator for remembering manually blurred elements across page reloads.
 */

function escapeCssIdent(str) {
  if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') {
    return CSS.escape(str);
  }
  return String(str).replace(/([!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~])/g, '\\$1');
}

/**
 * Detect volatile auto-generated IDs/classes (e.g. React/Emotion/Tailwind hashes) so
 * saved per-domain selectors stay resilient across reloads.
 */
export function isLikelyStableIdentifier(value) {
  if (!value || typeof value !== 'string') return false;
  if (value.length > 48) return false;
  // Reject strings with long digit runs or random hex-like hashes
  if (/\d{4,}/.test(value)) return false;
  if (/^(?:css|sc|emotion|styled|jsx|radix|headlessui|mui)-/i.test(value)) return false;
  if (/^:r[0-9a-z]+:$/i.test(value)) return false;
  if (/^[a-f0-9]{8,}$/i.test(value)) return false;
  return /^[A-Za-z_-][A-Za-z0-9_-]*$/.test(value);
}

/**
 * Build a concise, stable CSS selector for an element inside a DOM tree.
 */
export function buildStableSelector(element) {
  if (!element || element.nodeType !== 1) return '';

  // 1. Prefer data-testid / aria-label if unique
  const testId = element.getAttribute?.('data-testid') || element.getAttribute?.('data-test-id');
  if (testId && testId.length <= 64) {
    const sel = `[data-testid="${testId.replace(/"/g, '\\"')}"]`;
    try {
      if (element.ownerDocument?.querySelectorAll(sel).length === 1) return sel;
    } catch {
      // fall through
    }
  }

  // 2. Prefer stable non-random ID
  if (element.id && isLikelyStableIdentifier(element.id)) {
    const sel = `#${escapeCssIdent(element.id)}`;
    try {
      if (element.ownerDocument?.querySelectorAll(sel).length === 1) return sel;
    } catch {
      // fall through
    }
  }

  // 3. Build ancestor path up to 4 levels
  const parts = [];
  let cur = element;
  let depth = 0;

  while (cur && cur.nodeType === 1 && cur.tagName !== 'HTML' && cur.tagName !== 'BODY' && depth < 5) {
    const tag = cur.tagName.toLowerCase();
    let part = tag;

    if (cur.id && isLikelyStableIdentifier(cur.id)) {
      parts.unshift(`#${escapeCssIdent(cur.id)}`);
      break;
    }

    const stableClasses = Array.from(cur.classList || [])
      .filter((c) => isLikelyStableIdentifier(c) && !c.startsWith('dc-'))
      .slice(0, 2);

    if (stableClasses.length > 0) {
      part += stableClasses.map((c) => `.${escapeCssIdent(c)}`).join('');
    }

    // Add nth-of-type if siblings share same tag
    const parent = cur.parentElement;
    if (parent) {
      const sameTagSiblings = Array.from(parent.children).filter((s) => s.tagName === cur.tagName);
      if (sameTagSiblings.length > 1) {
        const idx = sameTagSiblings.indexOf(cur) + 1;
        part += `:nth-of-type(${idx})`;
      }
    }

    parts.unshift(part);
    const candidate = parts.join(' > ');
    try {
      if (element.ownerDocument?.querySelectorAll(candidate).length === 1) {
        return candidate;
      }
    } catch {
      // keep climbing
    }

    cur = parent;
    depth += 1;
  }

  return parts.join(' > ');
}

/**
 * Extract safe origin match pattern (`https://example.com/*`) and hostname from a tab URL.
 */
export function parseTabOrigin(url) {
  try {
    const parsed = new URL(String(url || ''));
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return null;
    }
    return {
      hostname: parsed.hostname,
      origin: parsed.origin,
      originPattern: `${parsed.origin}/*`,
    };
  } catch {
    return null;
  }
}
