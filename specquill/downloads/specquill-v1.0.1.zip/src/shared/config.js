/**
 * SpecQuill commercial & monetization configuration (Orzi Apps Studio · Creem.io + Cloudflare Worker).
 */
export const CONFIG = Object.freeze({
  APP_NAME: 'SpecQuill',
  VERSION: '1.0.1',

  // Creem Product ID for SpecQuill Pro (sent to shared multi-product Worker for product scoping)
  PRODUCT_ID: 'prod_4mf62USuYfD1W1ui9NnUD1',

  // Deployed shared Cloudflare Worker URL proxying Creem.io /v1/licenses/*
  LICENSE_API_BASE: 'https://orzi-apps-license-api.orzi-apps.workers.dev',

  // Public Creem.io Checkout URL shown on Upgrade CTAs
  CHECKOUT_URL: 'https://www.creem.io/payment/prod_4mf62USuYfD1W1ui9NnUD1',
  HOMEPAGE_URL: 'https://apps.orzi.me/specquill/',
  STUDIO_URL: 'https://apps.orzi.me/',
  PRIVACY_URL: 'https://apps.orzi.me/privacy.html',
  TERMS_URL: 'https://apps.orzi.me/terms.html',
  SUPPORT_URL: 'https://github.com/orziz/orzi-apps-site/issues',

  // Pricing display strings
  LAUNCH_PRICE: '$12',
  STANDARD_PRICE: '$29',

  // Free tier limits (generous enough to earn 5-star reviews)
  FREE_DAILY_PRO_EXPORTS: 5,
  FREE_MAX_SUBTREE_NODES: 40,
  PRO_MAX_SUBTREE_NODES: 250,

  // License revalidation & offline grace window
  REVALIDATE_INTERVAL_MS: 12 * 60 * 60 * 1000, // 12 hours
  OFFLINE_GRACE_MS: 7 * 24 * 60 * 60 * 1000,   // 7 days
});
