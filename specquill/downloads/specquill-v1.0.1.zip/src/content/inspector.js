/**
 * SpecQuill On-Page Inspector Content Script
 * - Isolated Shadow DOM overlay (zero CSS bleed into/from host page)
 * - Live hover box-model + WCAG contrast HUD + Alt-key pixel distance redlines
 * - Click to lock + keyboard DOM navigation (ArrowUp/Down/Left/Right, Escape)
 * - Baseline style diffing using hidden clean reference elements per tag
 * - rAF-batched non-blocking full-page Design System & inline SVG scanner
 */
(() => {
  if (window.__specquillInstalled) {
    return;
  }
  window.__specquillInstalled = true;

  const STYLE_PROPS = [
    'display', 'position', 'z-index',
    'width', 'height', 'max-width', 'min-height',
    'margin-top', 'margin-right', 'margin-bottom', 'margin-left',
    'padding-top', 'padding-right', 'padding-bottom', 'padding-left',
    'border-top-width', 'border-right-width', 'border-bottom-width', 'border-left-width',
    'border-top-style', 'border-right-style', 'border-bottom-style', 'border-left-style',
    'border-top-color', 'border-right-color', 'border-bottom-color', 'border-left-color',
    'border-top-left-radius', 'border-top-right-radius', 'border-bottom-right-radius', 'border-bottom-left-radius',
    'background-color', 'background-image', 'color',
    'font-family', 'font-size', 'font-weight', 'font-style', 'line-height', 'letter-spacing',
    'text-align', 'text-transform', 'text-decoration-line', 'white-space',
    'flex-direction', 'flex-wrap', 'justify-content', 'align-items', 'gap', 'row-gap', 'column-gap',
    'grid-template-columns', 'grid-template-rows',
    'box-shadow', 'opacity', 'overflow', 'overflow-x', 'overflow-y', 'cursor',
  ];

  const SAFE_ATTRS = ['href', 'src', 'alt', 'type', 'placeholder', 'aria-label', 'role', 'name', 'value'];

  const state = {
    active: false,
    altPressed: false,
    hoveredEl: null,
    lockedEl: null,
    host: null,
    shadow: null,
    overlayBox: null,
    marginBox: null,
    hud: null,
    redlineLayer: null,
    toastEl: null,
    toastTimer: null,
    baselineCache: new Map(),
    baselineFrame: null,
  };

  function ensureOverlay() {
    if (state.host && document.documentElement.contains(state.host)) return;

    const host = document.createElement('div');
    host.id = 'specquill-overlay-host';
    host.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:2147483647;';
    const shadow = host.attachShadow({ mode: 'open' });

    const style = document.createElement('style');
    style.textContent = `
      :host { all: initial; font-family: ui-sans-serif, system-ui, -apple-system, sans-serif; }
      .ts-box {
        position: fixed;
        box-sizing: border-box;
        pointer-events: none;
        border: 2px solid #2563eb;
        background: rgba(37, 99, 235, 0.08);
        border-radius: 3px;
        transition: opacity 80ms ease;
        display: none;
      }
      .ts-box.locked {
        border-color: #059669;
        background: rgba(5, 150, 105, 0.08);
        box-shadow: 0 0 0 1px rgba(5, 150, 105, 0.35);
      }
      .ts-margin {
        position: fixed;
        box-sizing: border-box;
        pointer-events: none;
        border: 1px dashed rgba(245, 158, 11, 0.75);
        background: rgba(245, 158, 11, 0.08);
        display: none;
      }
      .ts-hud {
        position: fixed;
        pointer-events: none;
        background: #0f172a;
        color: #f8fafc;
        border: 1px solid #334155;
        border-radius: 8px;
        padding: 6px 10px;
        font-size: 12px;
        line-height: 1.4;
        box-shadow: 0 10px 24px rgba(0, 0, 0, 0.35);
        max-width: 320px;
        display: none;
        white-space: nowrap;
      }
      .ts-hud-row { display: flex; align-items: center; gap: 6px; }
      .ts-tag { color: #60a5fa; font-weight: 700; font-family: ui-monospace, SFMono-Regular, monospace; }
      .ts-dim { color: #cbd5e1; font-family: ui-monospace, SFMono-Regular, monospace; font-size: 11px; }
      .ts-meta { color: #94a3b8; font-size: 11px; margin-top: 2px; overflow: hidden; text-overflow: ellipsis; }
      .ts-badge {
        display: inline-block;
        padding: 1px 5px;
        border-radius: 4px;
        font-size: 10px;
        font-weight: 700;
      }
      .ts-badge.pass { background: #065f46; color: #d1fae5; }
      .ts-badge.fail { background: #7f1d1d; color: #fee2e2; }
      .ts-redlines { position: fixed; inset: 0; pointer-events: none; }
      .ts-line { position: fixed; background: #f43f5e; pointer-events: none; }
      .ts-line-label {
        position: fixed;
        background: #f43f5e;
        color: #ffffff;
        font-size: 10px;
        font-weight: 700;
        padding: 1px 4px;
        border-radius: 3px;
        font-family: ui-monospace, SFMono-Regular, monospace;
      }
      .ts-toast {
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: #0f172a;
        color: #f8fafc;
        border: 1px solid #334155;
        border-radius: 999px;
        padding: 8px 16px;
        font-size: 13px;
        font-weight: 500;
        box-shadow: 0 12px 28px rgba(0, 0, 0, 0.35);
        display: none;
      }
    `;

    const marginBox = document.createElement('div');
    marginBox.className = 'ts-margin';

    const overlayBox = document.createElement('div');
    overlayBox.className = 'ts-box';

    const hud = document.createElement('div');
    hud.className = 'ts-hud';

    const redlineLayer = document.createElement('div');
    redlineLayer.className = 'ts-redlines';

    const toastEl = document.createElement('div');
    toastEl.className = 'ts-toast';

    shadow.append(style, marginBox, overlayBox, redlineLayer, hud, toastEl);
    document.documentElement.appendChild(host);

    state.host = host;
    state.shadow = shadow;
    state.marginBox = marginBox;
    state.overlayBox = overlayBox;
    state.hud = hud;
    state.redlineLayer = redlineLayer;
    state.toastEl = toastEl;
  }

  function showToast(message, durationMs = 2600) {
    ensureOverlay();
    state.toastEl.textContent = message;
    state.toastEl.style.display = 'block';
    if (state.toastTimer) clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(() => {
      if (state.toastEl) state.toastEl.style.display = 'none';
    }, durationMs);
  }

  function getBaselineStyles(tag) {
    const key = tag.toLowerCase();
    if (state.baselineCache.has(key)) {
      return state.baselineCache.get(key);
    }
    try {
      if (!state.baselineFrame) {
        const iframe = document.createElement('iframe');
        iframe.setAttribute('aria-hidden', 'true');
        iframe.style.cssText = 'position:fixed;left:-9999px;top:-9999px;width:0;height:0;border:0;visibility:hidden;';
        document.documentElement.appendChild(iframe);
        state.baselineFrame = iframe;
      }
      const doc = state.baselineFrame.contentDocument;
      const win = state.baselineFrame.contentWindow;
      if (!doc || !win) return {};
      const el = doc.createElement(key);
      doc.body.appendChild(el);
      const cs = win.getComputedStyle(el);
      const out = {};
      for (const prop of STYLE_PROPS) {
        out[prop] = cs.getPropertyValue(prop);
      }
      el.remove();
      state.baselineCache.set(key, out);
      return out;
    } catch {
      return {};
    }
  }

  function readStyleMap(el) {
    const cs = window.getComputedStyle(el);
    const out = {};
    for (const prop of STYLE_PROPS) {
      out[prop] = cs.getPropertyValue(prop);
    }
    return out;
  }

  function getEffectiveBackground(el) {
    let cur = el;
    while (cur && cur.nodeType === 1) {
      const bg = window.getComputedStyle(cur).backgroundColor;
      if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') {
        return bg;
      }
      cur = cur.parentElement;
    }
    return 'rgb(255, 255, 255)';
  }

  function quickContrast(fgStr, bgStr) {
    const parseRgb = (s) => {
      const m = String(s || '').match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)/);
      return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null;
    };
    const fg = parseRgb(fgStr);
    const bg = parseRgb(bgStr);
    if (!fg || !bg) return null;
    const lum = (rgb) => {
      const [r, g, b] = rgb.map((v) => {
        const c = v / 255;
        return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
      });
      return 0.2126 * r + 0.7152 * g + 0.0722 * b;
    };
    const l1 = lum(fg);
    const l2 = lum(bg);
    return Number(((Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05)).toFixed(2));
  }

  function inferSemanticName(el) {
    const tag = el.tagName.toLowerCase();
    const role = el.getAttribute('role');
    if (role) return role.replace(/[^a-z0-9]/gi, '').toLowerCase();
    if (['button', 'nav', 'header', 'footer', 'article', 'aside', 'section', 'form'].includes(tag)) {
      return tag;
    }
    const cls = typeof el.className === 'string' ? el.className : '';
    const match = cls.match(/\b(card|badge|btn|button|hero|modal|alert|chip|pill|avatar|panel|tab|item|row|grid|banner|pricing)\b/i);
    return match ? match[1].toLowerCase() : tag;
  }

  function toComponentName(el) {
    const base = inferSemanticName(el);
    return `Extracted${base.charAt(0).toUpperCase()}${base.slice(1)}`;
  }

  function serializeElementTree(el, maxNodes = 80) {
    let count = 0;

    function walk(node, depth = 0) {
      if (count >= maxNodes || depth > 8) return null;
      if (node.nodeType === Node.TEXT_NODE) {
        const text = (node.textContent || '').replace(/\s+/g, ' ').trim();
        if (!text) return null;
        return { type: 'text', text };
      }
      if (node.nodeType !== Node.ELEMENT_NODE) return null;
      if (node === state.host) return null;

      const tag = node.tagName.toLowerCase();
      if (['script', 'style', 'noscript', 'template'].includes(tag)) return null;

      const cs = window.getComputedStyle(node);
      if (cs.display === 'none' || cs.visibility === 'hidden') return null;

      count += 1;

      if (tag === 'svg') {
        const clone = node.cloneNode(true);
        clone.removeAttribute('class');
        const outerSvg = clone.outerHTML.replace(/\s+/g, ' ').trim();
        return {
          type: 'element',
          tag: 'svg',
          semanticName: 'icon',
          outerSvg: outerSvg.length <= 8000 ? outerSvg : '<svg><!-- SVG truncated --></svg>',
          styles: readStyleMap(node),
          baseline: {},
          attrs: {},
          children: [],
        };
      }

      const attrs = {};
      for (const attr of SAFE_ATTRS) {
        const val = node.getAttribute(attr);
        if (val !== null && val !== '') attrs[attr] = val;
      }

      const children = [];
      for (const child of node.childNodes) {
        if (count >= maxNodes) break;
        const serialized = walk(child, depth + 1);
        if (serialized) children.push(serialized);
      }

      return {
        type: 'element',
        tag,
        semanticName: inferSemanticName(node),
        styles: readStyleMap(node),
        baseline: getBaselineStyles(tag),
        attrs,
        children,
      };
    }

    return { tree: walk(el, 0), nodeCount: count };
  }

  function buildBreadcrumb(el) {
    const parts = [];
    let cur = el;
    let steps = 0;
    while (cur && cur.nodeType === 1 && steps < 5) {
      const tag = cur.tagName.toLowerCase();
      const id = cur.id ? `#${cur.id}` : '';
      const firstClass = typeof cur.className === 'string'
        ? (cur.className.trim().split(/\s+/).find((c) => c && !c.includes(':')) || '')
        : '';
      parts.unshift(`${tag}${id || (firstClass ? `.${firstClass}` : '')}`);
      cur = cur.parentElement;
      steps += 1;
    }
    return parts;
  }

  function buildSnapshot(el) {
    const rect = el.getBoundingClientRect();
    const cs = window.getComputedStyle(el);
    const effectiveBackground = getEffectiveBackground(el);
    const { tree, nodeCount } = serializeElementTree(el, 120);

    return {
      url: location.href,
      title: document.title,
      tag: el.tagName.toLowerCase(),
      componentName: toComponentName(el),
      breadcrumb: buildBreadcrumb(el),
      nodeCount,
      rect: {
        width: Math.round(rect.width),
        height: Math.round(rect.height),
        top: Math.round(rect.top),
        left: Math.round(rect.left),
      },
      boxModel: {
        padding: [cs.paddingTop, cs.paddingRight, cs.paddingBottom, cs.paddingLeft],
        margin: [cs.marginTop, cs.marginRight, cs.marginBottom, cs.marginLeft],
        borderRadius: cs.borderRadius,
      },
      effectiveBackground,
      hasParent: Boolean(el.parentElement && el.parentElement !== document.documentElement),
      hasChildren: Boolean(el.firstElementChild),
      hasPrevSibling: Boolean(el.previousElementSibling),
      hasNextSibling: Boolean(el.nextElementSibling),
      tree,
    };
  }

  function clearRedlines() {
    if (state.redlineLayer) state.redlineLayer.innerHTML = '';
  }

  function drawRedlines(el) {
    clearRedlines();
    if (!state.altPressed || !el?.parentElement) return;
    const r = el.getBoundingClientRect();
    const p = el.parentElement.getBoundingClientRect();

    const segments = [
      { dist: Math.round(r.top - p.top), x: r.left + r.width / 2, y: p.top, w: 1, h: r.top - p.top },
      { dist: Math.round(p.bottom - r.bottom), x: r.left + r.width / 2, y: r.bottom, w: 1, h: p.bottom - r.bottom },
      { dist: Math.round(r.left - p.left), x: p.left, y: r.top + r.height / 2, w: r.left - p.left, h: 1 },
      { dist: Math.round(p.right - r.right), x: r.right, y: r.top + r.height / 2, w: p.right - r.right, h: 1 },
    ];

    for (const seg of segments) {
      if (seg.dist <= 1) continue;
      const line = document.createElement('div');
      line.className = 'ts-line';
      line.style.left = `${seg.x}px`;
      line.style.top = `${seg.y}px`;
      line.style.width = `${Math.max(1, seg.w)}px`;
      line.style.height = `${Math.max(1, seg.h)}px`;

      const label = document.createElement('div');
      label.className = 'ts-line-label';
      label.textContent = `${seg.dist}px`;
      label.style.left = `${seg.x + seg.w / 2 - 14}px`;
      label.style.top = `${seg.y + seg.h / 2 - 8}px`;
      state.redlineLayer.append(line, label);
    }
  }

  function renderHighlight(el, locked = false) {
    if (!el || el === state.host || !document.documentElement.contains(el)) {
      if (state.overlayBox) state.overlayBox.style.display = 'none';
      if (state.marginBox) state.marginBox.style.display = 'none';
      if (state.hud) state.hud.style.display = 'none';
      clearRedlines();
      return;
    }

    ensureOverlay();
    const rect = el.getBoundingClientRect();
    const cs = window.getComputedStyle(el);

    const mt = parseFloat(cs.marginTop) || 0;
    const mr = parseFloat(cs.marginRight) || 0;
    const mb = parseFloat(cs.marginBottom) || 0;
    const ml = parseFloat(cs.marginLeft) || 0;

    if (mt || mr || mb || ml) {
      state.marginBox.style.display = 'block';
      state.marginBox.style.top = `${rect.top - mt}px`;
      state.marginBox.style.left = `${rect.left - ml}px`;
      state.marginBox.style.width = `${rect.width + ml + mr}px`;
      state.marginBox.style.height = `${rect.height + mt + mb}px`;
    } else {
      state.marginBox.style.display = 'none';
    }

    state.overlayBox.className = locked ? 'ts-box locked' : 'ts-box';
    state.overlayBox.style.display = 'block';
    state.overlayBox.style.top = `${rect.top}px`;
    state.overlayBox.style.left = `${rect.left}px`;
    state.overlayBox.style.width = `${rect.width}px`;
    state.overlayBox.style.height = `${rect.height}px`;

    const bg = getEffectiveBackground(el);
    const ratio = quickContrast(cs.color, bg);
    const pass = ratio !== null && ratio >= 4.5;
    const fontShort = (cs.fontFamily || '').split(',')[0].replace(/['"]/g, '');

    state.hud.innerHTML = '';
    const row = document.createElement('div');
    row.className = 'ts-hud-row';
    const tagSpan = document.createElement('span');
    tagSpan.className = 'ts-tag';
    tagSpan.textContent = `<${el.tagName.toLowerCase()}>`;
    const dimSpan = document.createElement('span');
    dimSpan.className = 'ts-dim';
    dimSpan.textContent = `${Math.round(rect.width)}×${Math.round(rect.height)}`;
    row.append(tagSpan, dimSpan);

    if (ratio !== null) {
      const badge = document.createElement('span');
      badge.className = `ts-badge ${pass ? 'pass' : 'fail'}`;
      badge.textContent = `${ratio}:1 ${pass ? 'AA' : 'Low'}`;
      row.append(badge);
    }

    const meta = document.createElement('div');
    meta.className = 'ts-meta';
    meta.textContent = `${fontShort} ${cs.fontSize} · ${locked ? 'Locked (↑↓←→ nav, Esc exit)' : 'Click to lock · Hold Alt for distances'}`;

    state.hud.append(row, meta);
    state.hud.style.display = 'block';

    const hudHeight = 52;
    const top = rect.top > hudHeight + 12 ? rect.top - hudHeight - 6 : Math.min(window.innerHeight - hudHeight - 8, rect.bottom + 8);
    const left = Math.max(8, Math.min(window.innerWidth - 310, rect.left));
    state.hud.style.top = `${Math.max(8, top)}px`;
    state.hud.style.left = `${left}px`;

    drawRedlines(el);
  }

  function selectElement(el) {
    if (!el || el === state.host) return;
    state.lockedEl = el;
    renderHighlight(el, true);
    const payload = buildSnapshot(el);
    chrome.runtime.sendMessage({ type: 'SPECQUILL_ELEMENT_SELECTED', payload }).catch(() => {});
  }

  function onMouseMove(e) {
    if (!state.active || state.lockedEl) return;
    const target = document.elementFromPoint(e.clientX, e.clientY);
    if (!target || target === state.host || target === state.hoveredEl) return;
    state.hoveredEl = target;
    renderHighlight(target, false);
  }

  function onClick(e) {
    if (!state.active) return;
    const target = document.elementFromPoint(e.clientX, e.clientY);
    if (!target || target === state.host) return;
    e.preventDefault();
    e.stopPropagation();
    selectElement(target);
  }

  function onKeyDown(e) {
    if (!state.active) return;
    if (e.key === 'Alt') {
      state.altPressed = true;
      renderHighlight(state.lockedEl || state.hoveredEl, Boolean(state.lockedEl));
      return;
    }
    if (e.key === 'Escape') {
      if (state.lockedEl) {
        state.lockedEl = null;
        renderHighlight(state.hoveredEl, false);
      } else {
        stopPicker();
      }
      return;
    }
    if (!state.lockedEl) return;
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
      e.preventDefault();
      navigateLocked(e.key);
    }
  }

  function onKeyUp(e) {
    if (e.key === 'Alt') {
      state.altPressed = false;
      clearRedlines();
    }
  }

  function navigateLocked(direction) {
    const cur = state.lockedEl;
    if (!cur) return { ok: false, error: 'No element locked.' };
    let next = null;
    if ((direction === 'ArrowUp' || direction === 'parent') && cur.parentElement && cur.parentElement !== document.documentElement) {
      next = cur.parentElement;
    } else if ((direction === 'ArrowDown' || direction === 'child') && cur.firstElementChild) {
      next = cur.firstElementChild;
    } else if ((direction === 'ArrowLeft' || direction === 'prev') && cur.previousElementSibling) {
      next = cur.previousElementSibling;
    } else if ((direction === 'ArrowRight' || direction === 'next') && cur.nextElementSibling) {
      next = cur.nextElementSibling;
    }
    if (!next || next === state.host) return { ok: false, error: 'No target element in that direction.' };
    selectElement(next);
    return { ok: true };
  }

  function startPicker(toastMessage) {
    ensureOverlay();
    if (!state.active) {
      state.active = true;
      document.addEventListener('mousemove', onMouseMove, true);
      document.addEventListener('click', onClick, true);
      document.addEventListener('keydown', onKeyDown, true);
      document.addEventListener('keyup', onKeyUp, true);
    }
    state.lockedEl = null;
    if (toastMessage) showToast(toastMessage);
  }

  function stopPicker() {
    state.active = false;
    state.lockedEl = null;
    state.hoveredEl = null;
    document.removeEventListener('mousemove', onMouseMove, true);
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('keydown', onKeyDown, true);
    document.removeEventListener('keyup', onKeyUp, true);
    if (state.overlayBox) state.overlayBox.style.display = 'none';
    if (state.marginBox) state.marginBox.style.display = 'none';
    if (state.hud) state.hud.style.display = 'none';
    clearRedlines();
  }

  /**
   * Non-blocking, rAF-batched Design System & SVG scanner (Rule #6).
   */
  async function scanPageDesignSystem() {
    const allElements = Array.from(document.querySelectorAll('body *'))
      .filter((el) => el !== state.host && !state.host?.contains(el))
      .slice(0, 800);

    const colors = [];
    const fonts = new Set();
    const fontSizes = new Set();
    const radii = new Set();
    const shadows = new Set();
    const spacings = new Set();
    const svgs = [];
    const seenSvgHashes = new Set();

    const BATCH = 40;
    for (let i = 0; i < allElements.length; i += BATCH) {
      const batch = allElements.slice(i, i + BATCH);
      await new Promise((resolve) => {
        requestAnimationFrame(() => {
          for (const el of batch) {
            const tag = el.tagName.toLowerCase();
            if (['script', 'style', 'noscript', 'link', 'meta'].includes(tag)) continue;

            if (tag === 'svg' && svgs.length < 40) {
              const rect = el.getBoundingClientRect();
              if (rect.width >= 8 && rect.height >= 8) {
                const clone = el.cloneNode(true);
                const markup = clone.outerHTML.replace(/\s+/g, ' ').trim();
                if (markup.length <= 10000 && !seenSvgHashes.has(markup)) {
                  seenSvgHashes.add(markup);
                  svgs.push({
                    width: Math.round(rect.width),
                    height: Math.round(rect.height),
                    viewBox: el.getAttribute('viewBox') || `0 0 ${Math.round(rect.width)} ${Math.round(rect.height)}`,
                    label: el.getAttribute('aria-label') || el.querySelector('title')?.textContent?.trim() || `Icon${svgs.length + 1}`,
                    markup,
                  });
                }
              }
              continue;
            }

            const cs = window.getComputedStyle(el);
            if (cs.display === 'none' || cs.visibility === 'hidden') continue;

            if (cs.color) colors.push({ value: cs.color, role: 'text' });
            if (cs.backgroundColor && cs.backgroundColor !== 'rgba(0, 0, 0, 0)') {
              colors.push({ value: cs.backgroundColor, role: 'background' });
            }
            if (cs.borderTopWidth !== '0px' && cs.borderTopColor) {
              colors.push({ value: cs.borderTopColor, role: 'border' });
            }
            if (cs.fontFamily) fonts.add(cs.fontFamily);
            if (cs.fontSize) fontSizes.add(cs.fontSize);
            if (cs.borderRadius && cs.borderRadius !== '0px') radii.add(cs.borderRadius);
            if (cs.boxShadow && cs.boxShadow !== 'none') shadows.add(cs.boxShadow);
            if (cs.paddingTop && cs.paddingTop !== '0px') spacings.add(cs.paddingTop);
            if (cs.gap && cs.gap !== 'normal' && cs.gap !== '0px') spacings.add(cs.gap);
          }
          resolve();
        });
      });
      if (globalThis.scheduler?.yield) {
        await globalThis.scheduler.yield();
      }
    }

    // Collect accessible CSS custom properties from document stylesheets
    const cssVars = [];
    const seenVars = new Set();
    for (const sheet of Array.from(document.styleSheets)) {
      let rules;
      try {
        rules = sheet.cssRules;
      } catch {
        continue; // Cross-origin stylesheet, skip safely
      }
      if (!rules) continue;
      for (const rule of Array.from(rules)) {
        if (!rule.style) continue;
        for (let i = 0; i < rule.style.length; i++) {
          const prop = rule.style[i];
          if (prop.startsWith('--') && !seenVars.has(prop) && cssVars.length < 60) {
            seenVars.add(prop);
            cssVars.push({ name: prop, value: rule.style.getPropertyValue(prop).trim() });
          }
        }
      }
    }

    return {
      ok: true,
      scan: {
        url: location.href,
        title: document.title,
        colors,
        fonts: [...fonts],
        fontSizes: [...fontSizes],
        radii: [...radii],
        shadows: [...shadows],
        spacings: [...spacings],
        cssVars,
        svgs,
      },
    };
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || typeof message.type !== 'string') return false;

    if (message.type === 'SPECQUILL_PING') {
      sendResponse({ ok: true, active: state.active });
      return false;
    }
    if (message.type === 'SPECQUILL_START_PICKER') {
      startPicker(message.toastMessage);
      sendResponse({ ok: true });
      return false;
    }
    if (message.type === 'SPECQUILL_STOP_PICKER') {
      stopPicker();
      sendResponse({ ok: true });
      return false;
    }
    if (message.type === 'SPECQUILL_SHOW_TOAST') {
      showToast(message.message);
      sendResponse({ ok: true });
      return false;
    }
    if (message.type === 'SPECQUILL_NAVIGATE_DOM') {
      sendResponse(navigateLocked(message.direction));
      return false;
    }
    if (message.type === 'SPECQUILL_SCAN_PAGE') {
      (async () => {
        const result = await scanPageDesignSystem();
        sendResponse(result);
      })();
      return true;
    }
    return false;
  });
})();
