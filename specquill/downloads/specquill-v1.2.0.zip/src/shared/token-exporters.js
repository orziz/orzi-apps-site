import { buildColorPalette, getContrastReport, parseColor, rgbaToHex } from './color-math.js';
import { cleanComputedStyles, generateCleanHtmlAndCss } from './style-diff.js';
import { compileTreeToTailwind, convertSvgToJsx } from './tailwind-compiler.js';

/**
 * Rough token estimator for LLM context budgeting (~3.8 chars per token for code/markup).
 */
export function estimateTokens(text) {
  if (!text) return 0;
  return Math.max(1, Math.ceil(String(text).length / 3.8));
}

function sanitizeTokenSlug(name) {
  return String(name || 'token')
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'token';
}

/**
 * Normalizes a raw page design-system scan payload into clean structured tokens.
 */
export function normalizeDesignSystem(scan = {}) {
  const palette = buildColorPalette(scan.colors || [], 24);
  const fonts = [...new Set((scan.fonts || []).filter(Boolean))].slice(0, 8);
  const fontSizes = [...new Set((scan.fontSizes || []).filter(Boolean))]
    .sort((a, b) => parseFloat(a) - parseFloat(b))
    .slice(0, 12);
  const radii = [...new Set((scan.radii || []).filter((r) => r && r !== '0px'))]
    .sort((a, b) => parseFloat(a) - parseFloat(b))
    .slice(0, 8);
  const shadows = [...new Set((scan.shadows || []).filter((s) => s && s !== 'none'))].slice(0, 6);
  const spacings = [...new Set((scan.spacings || []).filter((s) => s && s !== '0px'))]
    .sort((a, b) => parseFloat(a) - parseFloat(b))
    .slice(0, 12);
  const cssVars = (scan.cssVars || []).slice(0, 60);
  const svgs = (scan.svgs || []).slice(0, 40);

  // Build WCAG contrast pairs between dominant backgrounds & text colors
  const surfaceCandidates = palette.filter((c) => c.roles.includes('background')).slice(0, 3);
  const textCandidates = palette.filter((c) => c.roles.includes('text')).slice(0, 6);
  const contrastAudit = [];
  for (const bg of surfaceCandidates) {
    for (const fg of textCandidates) {
      if (bg.hex === fg.hex) continue;
      const report = getContrastReport(fg.rgba, bg.rgba);
      contrastAudit.push({
        bgHex: bg.hex,
        bgToken: bg.tokenName,
        fgHex: fg.hex,
        fgToken: fg.tokenName,
        ...report,
      });
    }
  }

  return {
    url: scan.url || '',
    title: scan.title || 'Page Design System',
    palette,
    fonts,
    fontSizes,
    radii,
    shadows,
    spacings,
    cssVars,
    svgs,
    contrastAudit: contrastAudit.slice(0, 18),
  };
}

/**
 * FREE Exporter: Standard CSS :root custom properties.
 */
export function exportCssVariables(ds) {
  const lines = [
    `/* Extracted by SpecQuill from ${ds.url || 'active page'} */`,
    `:root {`,
    `  /* Colors */`,
    ...ds.palette.map((c) => `  --color-${sanitizeTokenSlug(c.tokenName)}: ${c.hex}; /* ${c.oklch} */`),
  ];

  if (ds.fonts.length) {
    lines.push('', '  /* Typography */');
    ds.fonts.forEach((font, i) => {
      const label = i === 0 ? 'primary' : i === 1 ? 'secondary' : `font-${i + 1}`;
      lines.push(`  --font-${label}: ${font};`);
    });
  }

  if (ds.radii.length) {
    lines.push('', '  /* Border Radii */');
    ds.radii.forEach((r, i) => lines.push(`  --radius-${i + 1}: ${r};`));
  }

  if (ds.shadows.length) {
    lines.push('', '  /* Elevation Shadows */');
    ds.shadows.forEach((s, i) => lines.push(`  --shadow-${i + 1}: ${s};`));
  }

  lines.push('}');
  return lines.join('\n');
}

/**
 * PRO Exporter: Tailwind CSS v4 @theme directive block.
 */
export function exportTailwindV4Theme(ds) {
  const lines = [
    `/* Tailwind CSS v4 @theme — extracted by SpecQuill */`,
    `@import "tailwindcss";`,
    ``,
    `@theme {`,
    `  /* Color Palette (OKLCH) */`,
    ...ds.palette.map((c) => `  --color-brand-${sanitizeTokenSlug(c.tokenName)}: ${c.oklch}; /* ${c.hex} */`),
  ];

  if (ds.fonts.length) {
    lines.push('', '  /* Fonts */');
    ds.fonts.forEach((font, i) => {
      const key = i === 0 ? 'sans' : i === 1 ? 'display' : `custom-${i + 1}`;
      lines.push(`  --font-${key}: ${font};`);
    });
  }

  if (ds.radii.length) {
    const names = ['xs', 'sm', 'md', 'lg', 'xl', '2xl', '3xl', 'full'];
    lines.push('', '  /* Radii */');
    ds.radii.forEach((r, i) => lines.push(`  --radius-brand-${names[i] || i + 1}: ${r};`));
  }

  if (ds.shadows.length) {
    const names = ['xs', 'sm', 'md', 'lg', 'xl', '2xl'];
    lines.push('', '  /* Shadows */');
    ds.shadows.forEach((s, i) => lines.push(`  --shadow-brand-${names[i] || i + 1}: ${s};`));
  }

  lines.push('}');
  return lines.join('\n');
}

/**
 * PRO Exporter: W3C Design Tokens Community Group (DTCG) JSON format.
 */
export function exportW3cDtcgJson(ds) {
  const doc = {
    $description: `Design tokens extracted by SpecQuill from ${ds.url || 'active page'}`,
    color: {},
    typography: {
      fontFamily: {},
      fontSize: {},
    },
    radius: {},
    shadow: {},
  };

  for (const c of ds.palette) {
    doc.color[sanitizeTokenSlug(c.tokenName)] = {
      $type: 'color',
      $value: c.hex,
      $extensions: {
        oklch: c.oklch,
        roles: c.roles,
        occurrences: c.count,
      },
    };
  }

  ds.fonts.forEach((font, i) => {
    doc.typography.fontFamily[i === 0 ? 'primary' : `font-${i + 1}`] = {
      $type: 'fontFamily',
      $value: font,
    };
  });

  ds.fontSizes.forEach((size, i) => {
    doc.typography.fontSize[`step-${i + 1}`] = {
      $type: 'dimension',
      $value: size,
    };
  });

  ds.radii.forEach((r, i) => {
    doc.radius[`radius-${i + 1}`] = {
      $type: 'dimension',
      $value: r,
    };
  });

  ds.shadows.forEach((s, i) => {
    doc.shadow[`elevation-${i + 1}`] = {
      $type: 'shadow',
      $value: s,
    };
  });

  return JSON.stringify(doc, null, 2);
}

/**
 * PRO Exporter: Figma Variables / Tokens Studio compatible JSON.
 */
export function exportFigmaVariablesJson(ds) {
  const variables = [];
  for (const c of ds.palette) {
    variables.push({
      name: `color/${sanitizeTokenSlug(c.tokenName)}`,
      type: 'COLOR',
      value: {
        r: Number((c.rgba.r / 255).toFixed(4)),
        g: Number((c.rgba.g / 255).toFixed(4)),
        b: Number((c.rgba.b / 255).toFixed(4)),
        a: c.rgba.a,
      },
      hex: c.hex,
    });
  }
  ds.radii.forEach((r, i) => {
    const num = parseFloat(r);
    if (!Number.isNaN(num)) {
      variables.push({ name: `radius/scale-${i + 1}`, type: 'FLOAT', value: num });
    }
  });
  ds.spacings.forEach((s, i) => {
    const num = parseFloat(s);
    if (!Number.isNaN(num)) {
      variables.push({ name: `spacing/step-${i + 1}`, type: 'FLOAT', value: num });
    }
  });
  return JSON.stringify({ collection: ds.title || 'Extracted Theme', modes: ['Default'], variables }, null, 2);
}

/**
 * PRO Exporter: AI Coding Agent Design System Rules (Cursor .mdc / CLAUDE.md / AGENTS.md).
 */
export function exportAgentRules(ds, target = 'cursor') {
  const header = target === 'cursor'
    ? [
        '---',
        `description: Design system tokens and styling constraints extracted from ${ds.url || 'reference site'}`,
        'globs: ["**/*.tsx", "**/*.jsx", "**/*.css", "**/*.html"]',
        'alwaysApply: false',
        '---',
        '',
      ].join('\n')
    : '';

  const colorLines = ds.palette.slice(0, 12)
    .map((c) => `- \`--color-${sanitizeTokenSlug(c.tokenName)}\`: \`${c.hex}\` (${c.oklch}) — used for ${c.roles.join(', ') || 'UI'}`)
    .join('\n');

  const fontLines = ds.fonts.length
    ? ds.fonts.map((f, i) => `- Font ${i + 1}: \`${f}\``).join('\n')
    : '- System sans-serif stack';

  const failingPairs = ds.contrastAudit.filter((p) => !p.passAA).slice(0, 5);
  const contrastNote = failingPairs.length
    ? `\n### Accessibility Warning (Fix Before Shipping)\n${failingPairs.map((p) => `- Avoid pairing \`${p.fgHex}\` on \`${p.bgHex}\` (contrast ${p.ratio}:1, fails WCAG AA).`).join('\n')}\n`
    : '\n### Accessibility\n- Maintain at least 4.5:1 text contrast and 3:1 UI component contrast.\n';

  return `${header}# Design System Specification (${ds.title})

Source reference: ${ds.url || 'Current page'}

## Color Tokens
Do not invent arbitrary hex colors. Stick strictly to these extracted tokens:
${colorLines || '- No non-transparent colors detected'}

## Typography
${fontLines}
- Font size scale: ${ds.fontSizes.join(', ') || '14px, 16px, 20px, 24px'}

## Shape & Elevation
- Border radii: ${ds.radii.join(', ') || '6px, 8px, 12px'}
- Spacing scale: ${ds.spacings.join(', ') || '4px, 8px, 12px, 16px, 24px'}
- Box shadows: ${ds.shadows.length ? ds.shadows.map((s) => `\`${s}\``).join('; ') : 'Flat / subtle borders'}
${contrastNote}
## Implementation Rules
1. Use semantic HTML elements and Tailwind CSS v4 utility classes or CSS custom properties matching the tokens above.
2. Preserve spacing rhythm, typography hierarchy, and responsive flex/grid behavior without hardcoding fixed pixel widths on fluid containers.
3. Ensure visible \`:focus-visible\` outlines and keyboard accessibility on all interactive controls.
`;
}

/**
 * PRO Exporter: Structured Component Prompt for Cursor / Claude Code / v0 / Antigravity.
 * Packages exact visual tokens + zero-bloat Tailwind JSX so LLMs recreate UI faithfully in 1 shot.
 */
export function exportAiComponentPrompt(snapshot, { target = 'cursor', format = 'tailwind-jsx' } = {}) {
  const tree = snapshot.tree;
  const rect = snapshot.rect || {};
  const rootClean = cleanComputedStyles(tree.styles, tree.baseline || {});

  // Gather unique colors & fonts inside this component subtree
  const colors = [];
  const fonts = new Set();
  function walk(node) {
    if (node.type === 'text') return;
    const s = node.styles || {};
    if (s.color) colors.push({ value: s.color, role: 'text' });
    if (s['background-color']) colors.push({ value: s['background-color'], role: 'background' });
    if (s['border-top-color'] && s['border-top-width'] !== '0px') {
      colors.push({ value: s['border-top-color'], role: 'border' });
    }
    if (s['font-family']) fonts.add(s['font-family']);
    for (const child of node.children || []) walk(child);
  }
  walk(tree);

  const localPalette = buildColorPalette(colors, 10);
  const codeBlock = format === 'css'
    ? (() => {
        const { html, css } = generateCleanHtmlAndCss(tree);
        return `### Clean HTML\n\`\`\`html\n${html}\n\`\`\`\n\n### Minimal CSS\n\`\`\`css\n${css}\n\`\`\``;
      })()
    : `### Reference Implementation (${format === 'tailwind-html' ? 'Tailwind HTML' : 'React + Tailwind v4'})\n\`\`\`tsx\n${compileTreeToTailwind(tree, { jsx: format !== 'tailwind-html', componentName: snapshot.componentName || 'ExtractedCard' })}\n\`\`\``;

  const bgColor = parseColor(snapshot.effectiveBackground || '#ffffff');
  const fgColor = parseColor(tree.styles?.color || '#000000');
  const contrast = getContrastReport(fgColor, bgColor, {
    fontSizePx: parseFloat(tree.styles?.['font-size']) || 16,
    fontWeight: parseInt(tree.styles?.['font-weight'], 10) || 400,
  });

  const targetHint = {
    cursor: 'Recreate this UI component cleanly in our project using React + Tailwind CSS v4. Keep props typed and responsive.',
    claude: 'Implement a production-ready, accessible component matching this exact visual specification and layout structure.',
    v0: 'Build an interactive, responsive React component matching these exact design tokens, spacing, and typography.',
    generic: 'Recreate this UI component accurately using the extracted tokens and clean markup below.',
  }[target] || 'Recreate this UI component accurately using the extracted tokens and clean markup below.';

  const prompt = `<component_spec source="${snapshot.url || 'webpage'}" tag="${tree.tag}" size="${Math.round(rect.width || 0)}x${Math.round(rect.height || 0)}px">
## Objective
${targetHint}

## Visual Tokens
- **Palette**: ${localPalette.map((c) => `\`${c.hex}\` (${c.roles.join('/')})`).join(', ') || 'Inherited'}
- **Fonts**: ${[...fonts].slice(0, 3).map((f) => `\`${f}\``).join(', ') || 'System UI'}
- **Root Layout**: \`display: ${rootClean.display || tree.styles?.display || 'block'}\`, padding \`${rootClean.padding || '0'}\`, radius \`${rootClean['border-radius'] || '0'}\`
- **WCAG Contrast (Root)**: ${contrast.ratio ? `${contrast.ratio}:1 (${contrast.level})` : 'N/A'}

${codeBlock}

## Constraints
- Preserve visual hierarchy, spacing rhythm, and contrast (>= 4.5:1 for text).
- Replace hardcoded placeholder text with clean component props.
- Avoid fixed pixel widths on fluid wrappers; use responsive padding and flex/grid wrapping.
</component_spec>`;

  return {
    prompt,
    tokens: estimateTokens(prompt),
  };
}

/**
 * Wraps an inline SVG string into a clean typed React TSX icon component.
 */
export function exportSvgReactComponent(svgMarkup, name = 'ExtractedIcon') {
  const cleanName = name.replace(/[^a-zA-Z0-9]/g, '') || 'ExtractedIcon';
  const jsxSvg = convertSvgToJsx(svgMarkup).replace('<svg', '<svg {...props}');
  return `import type { SVGProps } from 'react';

export function ${cleanName}(props: SVGProps<SVGSVGElement>) {
  return (
    ${jsxSvg}
  );
}
`;
}
