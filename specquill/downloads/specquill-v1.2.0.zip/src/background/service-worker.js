import { createLicenseClient } from '../shared/license-client.js';

const CONTEXT_MENU_INSPECT = 'specquill-inspect-element';
const CONTEXT_MENU_SCAN = 'specquill-scan-page';
const RESTRICTED_PREFIXES = ['chrome://', 'chrome-extension://', 'edge://', 'about:', 'view-source:'];

const licenseClient = createLicenseClient();

function isInspectableUrl(url) {
  if (!url || typeof url !== 'string') return false;
  if (url.startsWith('https://chromewebstore.google.com') || url.startsWith('https://chrome.google.com/webstore')) {
    return false;
  }
  return !RESTRICTED_PREFIXES.some((prefix) => url.startsWith(prefix));
}

async function ensureInspectorInjected(tabId) {
  try {
    const ping = await chrome.tabs.sendMessage(tabId, { type: 'SPECQUILL_PING' });
    if (ping?.ok) return { ok: true };
  } catch {
    // Not injected yet; inject below
  }

  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['src/content/inspector.js'],
    });
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err?.message || 'Unable to access this page.' };
  }
}

async function startInspectorOnTab(tab, { toastMessage } = {}) {
  if (!tab?.id || !isInspectableUrl(tab.url)) {
    return { ok: false, error: 'Cannot inspect browser internal or Chrome Web Store pages.' };
  }
  const injected = await ensureInspectorInjected(tab.id);
  if (!injected.ok) return injected;

  try {
    await chrome.tabs.sendMessage(tab.id, {
      type: 'SPECQUILL_START_PICKER',
      toastMessage,
    });
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err?.message || 'Failed to activate inspector.' };
  }
}

// Setup context menus on install/update
chrome.runtime.onInstalled.addListener(async () => {
  try {
    await chrome.contextMenus.removeAll();
    chrome.contextMenus.create({
      id: CONTEXT_MENU_INSPECT,
      title: 'Inspect UI with SpecQuill',
      contexts: ['page', 'selection', 'image', 'link'],
    });
    chrome.contextMenus.create({
      id: CONTEXT_MENU_SCAN,
      title: 'Scan Page Design System (SpecQuill)',
      contexts: ['page'],
    });
  } catch (err) {
    console.error('SpecQuill context menu setup error:', err);
  }
});

// Explicit side panel trigger on action icon click + immediate activeTab injection
chrome.action.onClicked.addListener(async (tab) => {
  try {
    await chrome.sidePanel.open({ windowId: tab.windowId });
    if (isInspectableUrl(tab.url)) {
      await startInspectorOnTab(tab, {
        toastMessage: 'SpecQuill active — hover any element and click to lock',
      });
    }
  } catch (err) {
    console.error('SpecQuill action click error:', err);
  }
});

// Keyboard shortcut (Alt+Shift+S)
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'toggle-inspector') return;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;
    await chrome.sidePanel.open({ windowId: tab.windowId });
    if (isInspectableUrl(tab.url)) {
      await startInspectorOnTab(tab, {
        toastMessage: 'SpecQuill inspector enabled (Esc to exit)',
      });
    }
  } catch (err) {
    console.error('SpecQuill command error:', err);
  }
});

// Context menu click with visible toast confirmation (Rule #9)
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id) return;
  try {
    await chrome.sidePanel.open({ windowId: tab.windowId });
    if (!isInspectableUrl(tab.url)) return;

    if (info.menuItemId === CONTEXT_MENU_INSPECT) {
      await startInspectorOnTab(tab, {
        toastMessage: 'SpecQuill picker active — click an element to inspect',
      });
    } else if (info.menuItemId === CONTEXT_MENU_SCAN) {
      const injected = await ensureInspectorInjected(tab.id);
      if (injected.ok) {
        await chrome.tabs.sendMessage(tab.id, {
          type: 'SPECQUILL_SHOW_TOAST',
          message: 'Scanning page design tokens in SpecQuill side panel...',
        });
        await chrome.storage.session.set({ pendingAction: { type: 'SCAN_PAGE', tabId: tab.id, ts: Date.now() } });
        try {
          await chrome.runtime.sendMessage({ type: 'SPECQUILL_TRIGGER_SCAN', tabId: tab.id });
        } catch {
          // Side panel may still be mounting and will read pendingAction on init
        }
      }
    }
  } catch (err) {
    console.error('SpecQuill context menu error:', err);
  }
});

// Central message router (always return true for async responses; zero global state)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== 'string') return false;

  if (message.type === 'SPECQUILL_ELEMENT_SELECTED' || message.type === 'SPECQUILL_ELEMENT_HOVERED') {
    // Persist latest selected snapshot in session storage so side panel catches it even if just opened
    if (message.type === 'SPECQUILL_ELEMENT_SELECTED') {
      (async () => {
        await chrome.storage.session.set({ lastSnapshot: message.payload });
        sendResponse({ ok: true });
      })();
      return true;
    }
    return false;
  }

  (async () => {
    try {
      switch (message.type) {
        case 'SPECQUILL_START_ON_TAB': {
          const tab = message.tabId
            ? await chrome.tabs.get(message.tabId)
            : (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
          const res = await startInspectorOnTab(tab, {
            toastMessage: 'SpecQuill picker active — click any element',
          });
          sendResponse(res);
          break;
        }
        case 'SPECQUILL_STOP_ON_TAB': {
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          if (tab?.id) {
            try {
              await chrome.tabs.sendMessage(tab.id, { type: 'SPECQUILL_STOP_PICKER' });
            } catch {
              // Content script not running on tab
            }
          }
          sendResponse({ ok: true });
          break;
        }
        case 'SPECQUILL_SCAN_PAGE_ON_TAB': {
          const tab = message.tabId
            ? await chrome.tabs.get(message.tabId)
            : (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
          if (!tab?.id || !isInspectableUrl(tab.url)) {
            sendResponse({ ok: false, error: 'Cannot scan restricted browser pages.' });
            break;
          }
          const injected = await ensureInspectorInjected(tab.id);
          if (!injected.ok) {
            sendResponse(injected);
            break;
          }
          const scanResult = await chrome.tabs.sendMessage(tab.id, { type: 'SPECQUILL_SCAN_PAGE' });
          sendResponse(scanResult);
          break;
        }
        case 'SPECQUILL_NAVIGATE_DOM': {
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          if (!tab?.id) {
            sendResponse({ ok: false, error: 'No active tab.' });
            break;
          }
          const navResult = await chrome.tabs.sendMessage(tab.id, {
            type: 'SPECQUILL_NAVIGATE_DOM',
            direction: message.direction,
          });
          sendResponse(navResult);
          break;
        }
        case 'SPECQUILL_LICENSE_STATUS': {
          const status = await licenseClient.validateLicense({ force: Boolean(message.force) });
          const quota = await licenseClient.getDailyQuotaStatus();
          sendResponse({ ok: true, license: status, quota });
          break;
        }
        case 'SPECQUILL_LICENSE_ACTIVATE': {
          const result = await licenseClient.activateLicense(message.licenseKey);
          const quota = await licenseClient.getDailyQuotaStatus();
          sendResponse({ ...result, quota });
          break;
        }
        case 'SPECQUILL_LICENSE_DEACTIVATE': {
          await licenseClient.deactivateLicense();
          const quota = await licenseClient.getDailyQuotaStatus();
          sendResponse({ ok: true, quota });
          break;
        }
        case 'SPECQUILL_CONSUME_QUOTA': {
          const quota = await licenseClient.consumeProExportQuota();
          sendResponse({ ok: true, quota });
          break;
        }
        default:
          sendResponse({ ok: false, error: 'Unknown message type.' });
      }
    } catch (err) {
      sendResponse({ ok: false, error: err?.message || 'Unexpected error.' });
    }
  })();

  return true;
});
