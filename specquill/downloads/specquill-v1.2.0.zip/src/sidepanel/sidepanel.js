import { CONFIG } from '../shared/config.js';
import { getContrastReport } from '../shared/color-math.js';
import { generateCleanHtmlAndCss } from '../shared/style-diff.js';
import { compileTreeToTailwind } from '../shared/tailwind-compiler.js';
import {
  estimateTokens,
  exportAgentRules,
  exportAiComponentPrompt,
  exportCssVariables,
  exportFigmaVariablesJson,
  exportSvgReactComponent,
  exportTailwindV4Theme,
  exportW3cDtcgJson,
  normalizeDesignSystem,
} from '../shared/token-exporters.js';

const PRO_ELEMENT_FORMATS = new Set(['tailwind-jsx', 'tailwind-html', 'ai-cursor', 'ai-claude', 'ai-v0']);
const PRO_TOKEN_FORMATS = new Set(['tailwind-theme', 'dtcg-json', 'figma-json', 'cursor-mdc', 'agents-md']);

function applySidepanelI18n() {
  try {
    if (!chrome?.i18n?.getMessage) return;
    document.querySelectorAll('[data-i18n]').forEach((el) => {
      const msg = chrome.i18n.getMessage(el.dataset.i18n);
      if (msg) el.textContent = msg;
    });
  } catch {
    // Fallback to English markup
  }
}
applySidepanelI18n();

const ui = {
  planBadge: document.getElementById('plan-badge'),
  btnInspect: document.getElementById('btn-inspect'),
  btnScan: document.getElementById('btn-scan'),
  btnStop: document.getElementById('btn-stop'),
  siteBanner: document.getElementById('site-banner'),
  siteBannerText: document.getElementById('site-banner-text'),
  btnGrantSite: document.getElementById('btn-grant-site'),
  tabs: Array.from(document.querySelectorAll('[role="tab"]')),
  panels: Array.from(document.querySelectorAll('[role="tabpanel"]')),
  elementEmpty: document.getElementById('element-empty'),
  elementDetail: document.getElementById('element-detail'),
  elTag: document.getElementById('el-tag'),
  elBreadcrumb: document.getElementById('el-breadcrumb'),
  elSize: document.getElementById('el-size'),
  elContrast: document.getElementById('el-contrast'),
  navParent: document.getElementById('nav-parent'),
  navChild: document.getElementById('nav-child'),
  navPrev: document.getElementById('nav-prev'),
  navNext: document.getElementById('nav-next'),
  specPadding: document.getElementById('spec-padding'),
  specMargin: document.getElementById('spec-margin'),
  specRadius: document.getElementById('spec-radius'),
  specNodes: document.getElementById('spec-nodes'),
  elementFormat: document.getElementById('element-format'),
  tokenCountPill: document.getElementById('token-count-pill'),
  elementCode: document.querySelector('#element-code code'),
  btnCopyElement: document.getElementById('btn-copy-element'),
  btnDownloadElement: document.getElementById('btn-download-element'),
  tokensEmpty: document.getElementById('tokens-empty'),
  tokensDetail: document.getElementById('tokens-detail'),
  paletteCount: document.getElementById('palette-count'),
  paletteGrid: document.getElementById('palette-grid'),
  typographySummary: document.getElementById('typography-summary'),
  contrastList: document.getElementById('contrast-list'),
  tokenFormat: document.getElementById('token-format'),
  tokenExportEst: document.getElementById('token-export-est'),
  tokenCode: document.querySelector('#token-code code'),
  btnCopyTokens: document.getElementById('btn-copy-tokens'),
  btnDownloadTokens: document.getElementById('btn-download-tokens'),
  svgsEmpty: document.getElementById('svgs-empty'),
  svgGrid: document.getElementById('svg-grid'),
  proPricePill: document.getElementById('pro-price-pill'),
  btnBuyPro: document.getElementById('btn-buy-pro'),
  licenseActiveBox: document.getElementById('license-active-box'),
  licenseMeta: document.getElementById('license-meta'),
  licenseForm: document.getElementById('license-form'),
  licenseInput: document.getElementById('license-key-input'),
  licenseError: document.getElementById('license-error'),
  btnRevalidate: document.getElementById('btn-revalidate'),
  btnDeactivate: document.getElementById('btn-deactivate'),
  upgradeDialog: document.getElementById('upgrade-dialog'),
  dialogBuyLink: document.getElementById('dialog-buy-link'),
  dialogEnterKey: document.getElementById('dialog-enter-key'),
  dialogClose: document.getElementById('dialog-close'),
  liveStatus: document.getElementById('live-status'),
};

const appState = {
  snapshot: null,
  designSystem: null,
  isPro: false,
  quota: { remaining: CONFIG.FREE_DAILY_PRO_EXPORTS, limit: CONFIG.FREE_DAILY_PRO_EXPORTS, canExportPro: true },
  activeTabId: null,
  activeOriginPattern: null,
  toastTimer: null,
};

function announce(message) {
  ui.liveStatus.textContent = message;
  ui.liveStatus.classList.add('visible');
  if (appState.toastTimer) clearTimeout(appState.toastTimer);
  appState.toastTimer = setTimeout(() => {
    ui.liveStatus.classList.remove('visible');
  }, 2400);
}

function selectTab(tabId) {
  ui.tabs.forEach((tab) => {
    const active = tab.id === tabId;
    tab.setAttribute('aria-selected', String(active));
    tab.tabIndex = active ? 0 : -1;
  });
  ui.panels.forEach((panel) => {
    panel.hidden = panel.getAttribute('aria-labelledby') !== tabId;
  });
}

function setupTabs() {
  ui.tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => selectTab(tab.id));
    tab.addEventListener('keydown', (e) => {
      let nextIdx = null;
      if (e.key === 'ArrowRight') nextIdx = (index + 1) % ui.tabs.length;
      if (e.key === 'ArrowLeft') nextIdx = (index - 1 + ui.tabs.length) % ui.tabs.length;
      if (e.key === 'Home') nextIdx = 0;
      if (e.key === 'End') nextIdx = ui.tabs.length - 1;
      if (nextIdx !== null) {
        e.preventDefault();
        selectTab(ui.tabs[nextIdx].id);
        ui.tabs[nextIdx].focus();
      }
    });
  });
}

function updateLicenseUI(license, quota) {
  appState.isPro = Boolean(license?.isPro);
  appState.quota = quota || appState.quota;

  if (appState.isPro) {
    ui.planBadge.textContent = 'PRO';
    ui.planBadge.classList.add('pro');
    ui.licenseActiveBox.hidden = false;
    ui.licenseForm.hidden = true;
    const email = license?.record?.customerEmail ? `· ${license.record.customerEmail}` : '';
    ui.licenseMeta.textContent = email;
  } else {
    const rem = appState.quota?.remaining ?? CONFIG.FREE_DAILY_PRO_EXPORTS;
    const lim = appState.quota?.limit ?? CONFIG.FREE_DAILY_PRO_EXPORTS;
    ui.planBadge.textContent = `Free · ${rem}/${lim} left`;
    ui.planBadge.classList.remove('pro');
    ui.licenseActiveBox.hidden = true;
    ui.licenseForm.hidden = false;
  }
  if (appState.snapshot) renderElementCode();
  if (appState.designSystem) renderTokenCode();
}

async function refreshLicenseStatus(force = false) {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'SPECQUILL_LICENSE_STATUS', force });
    if (res?.ok) {
      updateLicenseUI(res.license, res.quota);
    }
  } catch (err) {
    console.warn('License status check failed:', err);
  }
}

async function refreshActiveTabOrigin() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    appState.activeTabId = tab?.id || null;
    if (tab?.url && /^https?:\/\//.test(tab.url)) {
      const origin = new URL(tab.url).origin;
      appState.activeOriginPattern = `${origin}/*`;
    } else {
      appState.activeOriginPattern = null;
    }
  } catch {
    appState.activeOriginPattern = null;
  }
}

function showSitePermissionBanner(reason) {
  if (!appState.activeOriginPattern) {
    announce(reason || 'Open a normal http/https webpage to inspect.');
    return;
  }
  ui.siteBannerText.textContent = `Allow SpecQuill on ${appState.activeOriginPattern.replace('/*', '')} to inspect this tab.`;
  ui.siteBanner.hidden = false;
}

function compileElementOutput() {
  if (!appState.snapshot?.tree) return { text: '', ext: 'txt', isProFormat: false };
  const fmt = ui.elementFormat.value;
  const isProFormat = PRO_ELEMENT_FORMATS.has(fmt);

  let text = '';
  let ext = 'txt';

  if (fmt === 'css') {
    const { html, css } = generateCleanHtmlAndCss(appState.snapshot.tree);
    text = `<!-- Clean HTML -->\n${html}\n\n/* Zero-Bloat CSS */\n${css}`;
    ext = 'html';
  } else if (fmt === 'tailwind-jsx') {
    text = compileTreeToTailwind(appState.snapshot.tree, {
      jsx: true,
      componentName: appState.snapshot.componentName || 'ExtractedComponent',
    });
    ext = 'tsx';
  } else if (fmt === 'tailwind-html') {
    text = compileTreeToTailwind(appState.snapshot.tree, { jsx: false });
    ext = 'html';
  } else if (fmt.startsWith('ai-')) {
    const target = fmt.replace('ai-', '');
    const res = exportAiComponentPrompt(appState.snapshot, { target, format: 'tailwind-jsx' });
    text = res.prompt;
    ext = 'md';
  }

  return { text, ext, isProFormat };
}

function renderElementSnapshot(snapshot) {
  appState.snapshot = snapshot;
  ui.elementEmpty.hidden = true;
  ui.elementDetail.hidden = false;

  ui.elTag.textContent = `<${snapshot.tag}>`;
  ui.elBreadcrumb.textContent = (snapshot.breadcrumb || []).join(' › ');
  ui.elSize.textContent = `${snapshot.rect?.width || 0}×${snapshot.rect?.height || 0}px`;

  const rootStyles = snapshot.tree?.styles || {};
  const contrast = getContrastReport(rootStyles.color, snapshot.effectiveBackground, {
    fontSizePx: parseFloat(rootStyles['font-size']) || 16,
    fontWeight: parseInt(rootStyles['font-weight'], 10) || 400,
  });

  ui.elContrast.className = 'pill';
  if (contrast.ratio) {
    ui.elContrast.textContent = `${contrast.passAA ? '✓' : '✗'} ${contrast.ratio}:1 ${contrast.level}`;
    ui.elContrast.classList.add(contrast.passAA ? 'pass' : 'fail');
  } else {
    ui.elContrast.textContent = 'Contrast N/A';
  }

  ui.specPadding.textContent = (snapshot.boxModel?.padding || []).join(' ');
  ui.specMargin.textContent = (snapshot.boxModel?.margin || []).join(' ');
  ui.specRadius.textContent = snapshot.boxModel?.borderRadius || '0px';
  ui.specNodes.textContent = `${snapshot.nodeCount || 1} nodes`;

  ui.navParent.disabled = !snapshot.hasParent;
  ui.navChild.disabled = !snapshot.hasChildren;
  ui.navPrev.disabled = !snapshot.hasPrevSibling;
  ui.navNext.disabled = !snapshot.hasNextSibling;

  renderElementCode();
}

function formatGatedPreview(text, isProFormat) {
  if (!text || appState.isPro || !isProFormat) return text;
  const remaining = appState.quota?.remaining ?? CONFIG.FREE_DAILY_PRO_EXPORTS;
  if (remaining > 0) return text;
  const lines = text.split('\n');
  const preview = lines.slice(0, 8).join('\n');
  return `${preview}\n\n/* ─── Daily free Pro limit reached (${CONFIG.FREE_DAILY_PRO_EXPORTS}/day) ───\n   Unlock unlimited React/Tailwind v4, AI prompts & tokens (${CONFIG.LAUNCH_PRICE} one-time)\n   Click Copy or open the Pro tab to activate your lifetime key. */`;
}

function renderElementCode() {
  const { text, isProFormat } = compileElementOutput();
  ui.elementCode.textContent = formatGatedPreview(text, isProFormat);
  ui.tokenCountPill.textContent = `~${estimateTokens(text)} tokens`;
}

function compileTokenOutput() {
  if (!appState.designSystem) return { text: '', filename: 'tokens.css', isProFormat: false };
  const fmt = ui.tokenFormat.value;
  const isProFormat = PRO_TOKEN_FORMATS.has(fmt);

  switch (fmt) {
    case 'css-vars':
      return { text: exportCssVariables(appState.designSystem), filename: 'tokens.css', isProFormat };
    case 'tailwind-theme':
      return { text: exportTailwindV4Theme(appState.designSystem), filename: 'theme.css', isProFormat };
    case 'dtcg-json':
      return { text: exportW3cDtcgJson(appState.designSystem), filename: 'design-tokens.dtcg.json', isProFormat };
    case 'figma-json':
      return { text: exportFigmaVariablesJson(appState.designSystem), filename: 'figma-variables.json', isProFormat };
    case 'cursor-mdc':
      return { text: exportAgentRules(appState.designSystem, 'cursor'), filename: 'design-system.mdc', isProFormat };
    case 'agents-md':
      return { text: exportAgentRules(appState.designSystem, 'agents'), filename: 'AGENTS.md', isProFormat };
    default:
      return { text: '', filename: 'tokens.txt', isProFormat: false };
  }
}

function renderTokenCode() {
  const { text, isProFormat } = compileTokenOutput();
  ui.tokenCode.textContent = formatGatedPreview(text, isProFormat);
  ui.tokenExportEst.textContent = `~${estimateTokens(text)} tokens`;
}

function renderDesignSystem(ds) {
  appState.designSystem = ds;
  ui.tokensEmpty.hidden = true;
  ui.tokensDetail.hidden = false;

  // Palette swatches
  ui.paletteCount.textContent = `${ds.palette.length} colors`;
  ui.paletteGrid.innerHTML = '';
  for (const color of ds.palette) {
    const li = document.createElement('li');
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'swatch-btn';
    btn.setAttribute('aria-label', `Copy color ${color.tokenName} ${color.hex}`);

    const chip = document.createElement('span');
    chip.className = 'swatch-chip';
    chip.style.backgroundColor = color.hex;

    const meta = document.createElement('span');
    meta.className = 'swatch-meta';
    const name = document.createElement('span');
    name.className = 'swatch-name';
    name.textContent = color.tokenName;
    const hex = document.createElement('span');
    hex.className = 'swatch-hex';
    hex.textContent = color.hex;

    meta.append(name, hex);
    btn.append(chip, meta);
    btn.addEventListener('click', async () => {
      await copyText(color.hex, `Copied ${color.hex} (${color.oklch})`);
    });
    li.append(btn);
    ui.paletteGrid.append(li);
  }

  // Typography & radii pills
  ui.typographySummary.innerHTML = '';
  for (const font of ds.fonts.slice(0, 4)) {
    const span = document.createElement('span');
    span.className = 'pill';
    span.textContent = `Font: ${font.split(',')[0].replace(/['"]/g, '')}`;
    ui.typographySummary.append(span);
  }
  for (const r of ds.radii.slice(0, 4)) {
    const span = document.createElement('span');
    span.className = 'pill mono';
    span.textContent = `r:${r}`;
    ui.typographySummary.append(span);
  }

  // Contrast audit list
  ui.contrastList.innerHTML = '';
  if (ds.contrastAudit.length === 0) {
    const li = document.createElement('li');
    li.className = 'muted small-text';
    li.textContent = 'No distinct background/text pairs found.';
    ui.contrastList.append(li);
  } else {
    for (const pair of ds.contrastAudit.slice(0, 8)) {
      const li = document.createElement('li');
      li.className = 'contrast-row';

      const sample = document.createElement('span');
      sample.className = 'contrast-sample';
      sample.style.color = pair.fgHex;
      sample.style.backgroundColor = pair.bgHex;
      sample.textContent = 'Aa';

      const label = document.createElement('span');
      label.className = 'mono small-text';
      label.textContent = `${pair.fgHex} / ${pair.bgHex}`;

      const badge = document.createElement('span');
      badge.className = `pill ${pair.passAA ? 'pass' : 'fail'}`;
      badge.textContent = `${pair.passAA ? '✓' : '✗'} ${pair.ratio}:1 ${pair.level}`;

      li.append(sample, label, badge);
      ui.contrastList.append(li);
    }
  }

  renderTokenCode();
  renderSvgGallery(ds.svgs || []);
}

function renderSvgGallery(svgs) {
  ui.svgGrid.innerHTML = '';
  if (!svgs.length) {
    ui.svgsEmpty.hidden = false;
    ui.svgGrid.hidden = true;
    return;
  }
  ui.svgsEmpty.hidden = true;
  ui.svgGrid.hidden = false;

  svgs.forEach((item, idx) => {
    const li = document.createElement('li');
    li.className = 'svg-card';

    const preview = document.createElement('div');
    preview.className = 'svg-preview';
    // Safe SVG preview via data URL inside <img> so embedded scripts cannot execute
    const img = document.createElement('img');
    img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(item.markup)}`;
    img.alt = item.label || `SVG icon ${idx + 1}`;
    preview.append(img);

    const meta = document.createElement('div');
    meta.className = 'small-text mono muted';
    meta.textContent = `${item.label} (${item.width}×${item.height})`;

    const actions = document.createElement('div');
    actions.className = 'card-footer';

    const btnSvg = document.createElement('button');
    btnSvg.type = 'button';
    btnSvg.className = 'btn small secondary';
    btnSvg.textContent = 'Copy SVG';
    btnSvg.addEventListener('click', async () => {
      await copyText(item.markup, `Copied ${item.label} SVG`);
    });

    const btnJsx = document.createElement('button');
    btnJsx.type = 'button';
    btnJsx.className = 'btn small primary';
    btnJsx.textContent = 'TSX (Pro)';
    btnJsx.addEventListener('click', async () => {
      const allowed = await gateProExport();
      if (!allowed) return;
      const code = exportSvgReactComponent(item.markup, item.label || `Icon${idx + 1}`);
      await copyText(code, `Copied ${item.label} React TSX component`);
    });

    actions.append(btnSvg, btnJsx);
    li.append(preview, meta, actions);
    ui.svgGrid.append(li);
  });
}

async function gateProExport() {
  if (appState.isPro) return true;
  const res = await chrome.runtime.sendMessage({ type: 'SPECQUILL_CONSUME_QUOTA' });
  if (res?.quota) {
    updateLicenseUI({ isPro: res.quota.isPro }, res.quota);
    if (res.quota.allowed) return true;
  }
  ui.upgradeDialog.showModal();
  return false;
}

async function copyText(text, successMsg = 'Copied to clipboard') {
  try {
    await navigator.clipboard.writeText(text);
    announce(successMsg);
  } catch {
    announce('Clipboard permission unavailable.');
  }
}

function downloadTextFile(content, filename) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  announce(`Downloaded ${filename}`);
}

async function handleStartInspect() {
  const res = await chrome.runtime.sendMessage({
    type: 'SPECQUILL_START_ON_TAB',
    tabId: appState.activeTabId,
  });
  if (res?.ok) {
    ui.siteBanner.hidden = true;
    ui.btnStop.hidden = false;
    selectTab('tab-element');
    announce('Picker active — hover and click any element on the page.');
  } else {
    showSitePermissionBanner(res?.error);
  }
}

async function handleScanPage() {
  ui.btnScan.disabled = true;
  try {
    const res = await chrome.runtime.sendMessage({
      type: 'SPECQUILL_SCAN_PAGE_ON_TAB',
      tabId: appState.activeTabId,
    });
    if (res?.ok && res.scan) {
      ui.siteBanner.hidden = true;
      const ds = normalizeDesignSystem(res.scan);
      renderDesignSystem(ds);
      selectTab('tab-tokens');
      announce(`Extracted ${ds.palette.length} colors, ${ds.fonts.length} fonts, and ${ds.svgs.length} SVGs.`);
    } else {
      showSitePermissionBanner(res?.error);
    }
  } finally {
    ui.btnScan.disabled = false;
  }
}

// Synchronous per-origin permission request directly on click (Rule #20: zero await before request!)
ui.btnGrantSite.addEventListener('click', async () => {
  const origin = appState.activeOriginPattern;
  if (!origin) return;
  try {
    const granted = await chrome.permissions.request({ origins: [origin] });
    if (granted) {
      ui.siteBanner.hidden = true;
      announce('Site access granted.');
      await handleStartInspect();
    } else {
      announce('Site permission was declined.');
    }
  } catch (err) {
    announce(err?.message || 'Permission request failed.');
  }
});

ui.btnInspect.addEventListener('click', handleStartInspect);
ui.btnScan.addEventListener('click', handleScanPage);
ui.btnStop.addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'SPECQUILL_STOP_ON_TAB' });
  ui.btnStop.hidden = true;
  announce('Element picker paused.');
});

// DOM tree navigation buttons
for (const [btn, direction] of [
  [ui.navParent, 'parent'],
  [ui.navChild, 'child'],
  [ui.navPrev, 'prev'],
  [ui.navNext, 'next'],
]) {
  btn.addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ type: 'SPECQUILL_NAVIGATE_DOM', direction });
  });
}

ui.elementFormat.addEventListener('change', renderElementCode);
ui.tokenFormat.addEventListener('change', renderTokenCode);

ui.btnCopyElement.addEventListener('click', async () => {
  const { text, isProFormat } = compileElementOutput();
  if (!text) return;
  if (isProFormat && !(await gateProExport())) return;
  await copyText(text, 'Copied component code to clipboard');
});

ui.btnDownloadElement.addEventListener('click', async () => {
  const { text, ext, isProFormat } = compileElementOutput();
  if (!text) return;
  if (isProFormat && !(await gateProExport())) return;
  const base = (appState.snapshot?.componentName || 'component').toLowerCase();
  downloadTextFile(text, `${base}.${ext}`);
});

ui.btnCopyTokens.addEventListener('click', async () => {
  const { text, isProFormat } = compileTokenOutput();
  if (!text) return;
  if (isProFormat && !(await gateProExport())) return;
  await copyText(text, 'Copied design tokens to clipboard');
});

ui.btnDownloadTokens.addEventListener('click', async () => {
  const { text, filename, isProFormat } = compileTokenOutput();
  if (!text) return;
  if (isProFormat && !(await gateProExport())) return;
  downloadTextFile(text, filename);
});

// License form handlers
ui.licenseForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  ui.licenseError.hidden = true;
  const key = ui.licenseInput.value.trim();
  if (!key) return;

  const submitBtn = document.getElementById('btn-activate');
  submitBtn.disabled = true;
  try {
    const res = await chrome.runtime.sendMessage({
      type: 'SPECQUILL_LICENSE_ACTIVATE',
      licenseKey: key,
    });
    if (res?.ok) {
      updateLicenseUI({ isPro: true, record: res.record }, res.quota);
      ui.licenseInput.value = '';
      announce('SpecQuill Pro activated! All exports unlocked.');
    } else {
      ui.licenseError.textContent = res?.error || 'Could not activate license key.';
      ui.licenseError.hidden = false;
    }
  } finally {
    submitBtn.disabled = false;
  }
});

ui.btnRevalidate.addEventListener('click', async () => {
  await refreshLicenseStatus(true);
  announce('License status verified.');
});

ui.btnDeactivate.addEventListener('click', async () => {
  const res = await chrome.runtime.sendMessage({ type: 'SPECQUILL_LICENSE_DEACTIVATE' });
  updateLicenseUI({ isPro: false }, res?.quota);
  announce('License deactivated on this browser.');
});

// Native <dialog> upgrade prompt
ui.dialogClose.addEventListener('click', () => ui.upgradeDialog.close());
ui.dialogEnterKey.addEventListener('click', () => {
  ui.upgradeDialog.close();
  selectTab('tab-pro');
  ui.licenseInput.focus();
});

// Listen for element selections and context menu triggers
chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === 'SPECQUILL_ELEMENT_SELECTED' && message.payload) {
    ui.btnStop.hidden = false;
    renderElementSnapshot(message.payload);
    selectTab('tab-element');
  } else if (message?.type === 'SPECQUILL_TRIGGER_SCAN') {
    handleScanPage();
  }
});

chrome.tabs.onActivated.addListener(() => {
  refreshActiveTabOrigin();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (tabId === appState.activeTabId && changeInfo.url) {
    refreshActiveTabOrigin();
  }
});

// Initial boot
async function init() {
  setupTabs();
  ui.proPricePill.textContent = `${CONFIG.LAUNCH_PRICE} one-time`;
  ui.btnBuyPro.href = CONFIG.CHECKOUT_URL;
  ui.dialogBuyLink.href = CONFIG.CHECKOUT_URL;

  await refreshActiveTabOrigin();
  await refreshLicenseStatus(false);

  // Restore last selected element or pending scan action from session storage
  try {
    const session = await chrome.storage.session.get(['lastSnapshot', 'pendingAction']);
    if (session.lastSnapshot) {
      renderElementSnapshot(session.lastSnapshot);
    }
    if (session.pendingAction?.type === 'SCAN_PAGE' && Date.now() - session.pendingAction.ts < 8000) {
      await chrome.storage.session.remove('pendingAction');
      await handleScanPage();
    }
  } catch {
    // Session storage optional in non-extension previews
  }
}

init();
